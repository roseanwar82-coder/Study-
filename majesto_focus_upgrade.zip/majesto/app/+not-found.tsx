import { router } from 'expo-router';
import { Button } from '@/ui/Button';
import { EmptyState, Screen } from '@/ui/Layout';

export default function NotFound() {
  return (
    <Screen>
      <EmptyState
        icon="compass-outline"
        title="That page doesn't exist"
        body="The link may be old or mistyped."
        action={<Button title="Go to Today" onPress={() => router.replace('/')} />}
      />
    </Screen>
  );
}
