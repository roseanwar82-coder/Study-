import { useState } from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { MINUTE, formatMinutes } from '@/core/time';
import { actions } from '@/store';
import { Button } from '@/ui/Button';
import { TextField } from '@/ui/Inputs';
import { Chip, Screen } from '@/ui/Layout';
import { Txt } from '@/ui/Text';
import { space } from '@/ui/theme';

const GOALS = [30, 60, 90, 120];

export default function Onboarding() {
  const [name, setName] = useState('');
  const [goal, setGoal] = useState(60);

  const start = () => {
    actions.completeOnboarding(name, goal);
    router.replace('/');
  };

  return (
    <Screen edges={['top', 'bottom']} contentStyle={{ paddingTop: space.xxl * 2 }}>
      <View style={{ gap: space.sm }}>
        <Txt variant="display">Majesto</Txt>
        <Txt color="textDim">Train your attention. Remember what you learn. Show up every day.</Txt>
      </View>

      <TextField
        label="What should we call you?"
        placeholder="Your name (optional)"
        value={name}
        onChangeText={setName}
        autoCapitalize="words"
        returnKeyType="done"
        maxLength={40}
      />

      <View style={{ gap: space.md }}>
        <Txt variant="small" color="textDim">Daily focus goal</Txt>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
          {GOALS.map((g) => (
            <Chip key={g} label={formatMinutes(g * MINUTE)} selected={goal === g} onPress={() => setGoal(g)} />
          ))}
        </View>
        <Txt variant="caption" color="textFaint">You can change this any time in Profile.</Txt>
      </View>

      <Button title="Start" size="lg" onPress={start} />
    </Screen>
  );
}
