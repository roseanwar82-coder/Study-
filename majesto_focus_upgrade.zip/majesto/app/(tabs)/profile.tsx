import { useMemo, useState } from 'react';
import { Alert, Share, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { ACHIEVEMENTS, computeMetrics } from '@/core/achievements';
import { computeStreak } from '@/core/streak';
import { MINUTE, dayKey, formatMinutes } from '@/core/time';
import { levelProgress, levelTitle } from '@/core/xp';
import { cancelTimerEnd, ensureNotificationPermission } from '@/services/notifications';
import { actions, useApp } from '@/store';
import { Button } from '@/ui/Button';
import { Stepper, TextField, ToggleRow } from '@/ui/Inputs';
import { Card, Screen, SectionHeader } from '@/ui/Layout';
import { ProgressBar } from '@/ui/Progress';
import { Txt } from '@/ui/Text';
import { colors, radius, space } from '@/ui/theme';

export default function Profile() {
  const state = useApp((s) => s);
  const { settings } = state;
  const now = Date.now();

  const level = levelProgress(state.xp);
  const streak = useMemo(() => computeStreak(state.activity, dayKey(now)), [state.activity]); // eslint-disable-line react-hooks/exhaustive-deps
  const metrics = useMemo(() => computeMetrics(state, now), [state]); // eslint-disable-line react-hooks/exhaustive-deps
  const [name, setName] = useState(state.profile.name);

  const exportData = async () => {
    try {
      await Share.share({ title: 'Majesto backup', message: actions.exportJson() });
    } catch {
      Alert.alert('Could not export', 'Something went wrong while opening the share sheet.');
    }
  };

  const confirmReset = () =>
    Alert.alert('Erase everything?', 'Decks, cards, history, XP and settings will be deleted from this device. This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Erase',
        style: 'destructive',
        onPress: () => {
          cancelTimerEnd();
          actions.resetAll();
        },
      },
    ]);

  return (
    <Screen>
      <Txt variant="display">Profile</Txt>

      <Card style={{ gap: space.md }}>
        <View style={styles.levelRow}>
          <View style={{ flex: 1 }}>
            <Txt variant="small" color="textDim">Level {level.level}</Txt>
            <Txt variant="title">{levelTitle(level.level)}</Txt>
          </View>
          <Txt variant="small" color="textDim">{state.xp.toLocaleString()} XP</Txt>
        </View>
        <ProgressBar ratio={level.ratio} height={8} />
        <Txt variant="caption" color="textDim">{level.needed - level.current} XP to level {level.level + 1}</Txt>
      </Card>

      <View style={styles.grid}>
        <Stat label="Current streak" value={`${streak.current}d`} />
        <Stat label="Longest streak" value={`${streak.longest}d`} />
        <Stat label="Focus time" value={formatMinutes(metrics.totalFocusMs)} />
        <Stat label="Sessions" value={String(metrics.sessions)} />
        <Stat label="Cards answered" value={String(metrics.reviews)} />
        <Stat label="Drills played" value={String(metrics.drills)} />
      </View>

      <View style={{ gap: space.md }}>
        <SectionHeader title="Achievements" action={<Txt variant="small" color="textDim">{Object.keys(state.achievements).length} / {ACHIEVEMENTS.length}</Txt>} />
        <View style={{ gap: space.sm }}>
          {ACHIEVEMENTS.map((a) => {
            const done = !!state.achievements[a.id];
            const value = Math.min(a.target, a.progress(metrics));
            return (
              <View key={a.id} style={[styles.achievement, done && { borderColor: colors.gold + '77' }]}>
                <View style={{ flex: 1, gap: 4 }}>
                  <Txt style={{ fontWeight: '700', color: done ? colors.gold : colors.text }}>{a.title}</Txt>
                  <Txt variant="small" color="textDim">{a.description}</Txt>
                  {!done ? <ProgressBar ratio={value / a.target} height={4} /> : null}
                </View>
                <Txt variant="caption" color={done ? 'gold' : 'textFaint'}>{done ? 'Unlocked' : `${value} / ${a.target}`}</Txt>
              </View>
            );
          })}
        </View>
      </View>

      <View style={{ gap: space.md }}>
        <SectionHeader title="Settings" />
        <Card style={{ gap: space.md }}>
          <TextField label="Name" value={name} onChangeText={setName} onBlur={() => actions.setName(name)} onSubmitEditing={() => actions.setName(name)} maxLength={40} returnKeyType="done" autoCapitalize="words" />
          <Divider />
          <Stepper label="Daily focus goal" value={settings.dailyFocusGoalMin} min={10} max={480} step={10} format={(v) => formatMinutes(v * MINUTE)} onChange={(v) => actions.updateSettings({ dailyFocusGoalMin: v })} />
          <Stepper label="Daily card goal" value={settings.dailyReviewGoal} min={5} max={200} step={5} onChange={(v) => actions.updateSettings({ dailyReviewGoal: v })} />
          <Stepper label="Daily drill goal" value={settings.dailyDrillGoal} min={1} max={10} onChange={(v) => actions.updateSettings({ dailyDrillGoal: v })} />
          <Divider />
          <Stepper label="Focus block" value={settings.focusMin} min={5} max={180} step={5} format={(v) => `${v} min`} onChange={(v) => actions.updateSettings({ focusMin: v })} />
          <Stepper label="Break" value={settings.breakMin} min={1} max={60} format={(v) => `${v} min`} onChange={(v) => actions.updateSettings({ breakMin: v })} />
          <Stepper label="New cards per day" value={settings.newCardsPerDay} min={0} max={100} step={5} onChange={(v) => actions.updateSettings({ newCardsPerDay: v })} />
          <Divider />
          <ToggleRow label="Type answers before revealing" hint="Recall harder by writing what you remember first." value={settings.typedRecall} onChange={(v) => actions.updateSettings({ typedRecall: v })} />
          <ToggleRow label="Haptics" value={settings.haptics} onChange={(v) => actions.updateSettings({ haptics: v })} />
          <ToggleRow
            label="Timer alerts"
            hint="A notification when a block or break ends."
            value={settings.notifications}
            onChange={(v) => {
              actions.updateSettings({ notifications: v });
              if (v) ensureNotificationPermission();
            }}
          />
          <Divider />
          <Button title="Focus guard & AI help" icon="shield-checkmark-outline" variant="secondary" onPress={() => router.push('/focus-guard')} />
        </Card>
      </View>

      <View style={{ gap: space.md }}>
        <SectionHeader title="Your data" />
        <Txt variant="small" color="textDim">Everything lives on this device. Export a backup any time.</Txt>
        <Button title="Export backup" icon="share-outline" variant="secondary" onPress={exportData} />
        <Button title="Erase all data" variant="danger" onPress={confirmReset} />
      </View>

      <Txt variant="caption" color="textFaint" style={{ textAlign: 'center' }}>Majesto 1.0.0</Txt>
    </Screen>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.stat}>
      <Txt variant="title">{value}</Txt>
      <Txt variant="caption" color="textDim">{label}</Txt>
    </View>
  );
}

const Divider = () => <View style={{ height: 1, backgroundColor: colors.border }} />;

const styles = StyleSheet.create({
  levelRow: { flexDirection: 'row', alignItems: 'flex-end' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: space.md },
  stat: {
    width: '47.5%',
    gap: 2,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.lg,
  },
  achievement: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.md,
  },
});
