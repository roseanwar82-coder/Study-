import type { ComponentProps } from 'react';
import { Redirect, Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '@/store';
import { areaColor, colors } from '@/ui/theme';

type IconPair = [active: ComponentProps<typeof Ionicons>['name'], inactive: ComponentProps<typeof Ionicons>['name']];

function tab(title: string, icons: IconPair, tint: string) {
  return {
    title,
    tabBarActiveTintColor: tint,
    tabBarIcon: ({ color, focused }: { color: string; focused: boolean }) => (
      <Ionicons name={focused ? icons[0] : icons[1]} size={22} color={color} />
    ),
  };
}

export default function TabsLayout() {
  const onboarded = useApp((s) => s.profile.onboarded);
  if (!onboarded) return <Redirect href="/onboarding" />;

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarInactiveTintColor: colors.textFaint,
        tabBarStyle: { backgroundColor: colors.bg, borderTopColor: colors.border },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
        sceneStyle: { backgroundColor: colors.bg },
      }}
    >
      <Tabs.Screen name="index" options={tab('Today', ['sunny', 'sunny-outline'], colors.text)} />
      <Tabs.Screen name="focus" options={tab('Focus', ['timer', 'timer-outline'], areaColor.focus)} />
      <Tabs.Screen name="recall" options={tab('Recall', ['layers', 'layers-outline'], areaColor.recall)} />
      <Tabs.Screen name="drills" options={tab('Drills', ['flash', 'flash-outline'], areaColor.drills)} />
      <Tabs.Screen name="profile" options={tab('Profile', ['person', 'person-outline'], colors.text)} />
    </Tabs>
  );
}
