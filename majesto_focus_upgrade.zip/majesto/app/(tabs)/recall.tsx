import { useMemo, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { countsForDeck } from '@/core/stats';
import { useNow } from '@/ui/hooks';
import { haptic } from '@/services/haptics';
import { actions, useApp } from '@/store';
import { DECK_COLORS } from '@/store/state';
import { Button } from '@/ui/Button';
import { TextField } from '@/ui/Inputs';
import { Card, EmptyState, Screen } from '@/ui/Layout';
import { Sheet } from '@/ui/Sheet';
import { Txt } from '@/ui/Text';
import { areaColor, colors, radius, space } from '@/ui/theme';

export default function Recall() {
  const state = useApp((s) => s);
  const now = useNow(true, 30_000);
  const [creating, setCreating] = useState(false);

  const total = useMemo(() => countsForDeck(state, null, now), [state, now]);
  const rows = useMemo(
    () =>
      state.decks.map((deck) => ({
        deck,
        cards: state.cards.filter((c) => c.deckId === deck.id).length,
        counts: countsForDeck(state, deck.id, now),
      })),
    [state, now],
  );

  return (
    <Screen>
      <View style={styles.header}>
        <Txt variant="display" style={{ flex: 1 }}>Recall</Txt>
        <Button title="New deck" icon="add" variant="secondary" onPress={() => setCreating(true)} />
      </View>

      <Card tint={areaColor.recall} style={{ gap: space.md }}>
        <View style={styles.countRow}>
          <Count label="Due" value={total.review} />
          <Count label="Learning" value={total.learning} />
          <Count label="New" value={total.new} />
        </View>
        <Button
          title={total.total > 0 ? `Review ${total.total} card${total.total === 1 ? '' : 's'}` : 'All caught up'}
          tint={areaColor.recall}
          size="lg"
          disabled={total.total === 0}
          onPress={() => router.push('/review/all')}
        />
        {total.total === 0 ? (
          <Txt variant="small" color="textDim" style={{ textAlign: 'center' }}>
            {state.cards.length === 0 ? 'Add some cards to get started.' : 'Nothing is due right now. Check back later.'}
          </Txt>
        ) : null}
      </Card>

      {rows.length === 0 ? (
        <EmptyState
          icon="layers-outline"
          title="No decks yet"
          body="A deck is a set of cards on one topic. Make one, add a few cards, and review them a little every day."
          action={<Button title="Create a deck" onPress={() => setCreating(true)} />}
        />
      ) : (
        <View style={{ gap: space.md }}>
          {rows.map(({ deck, cards, counts }) => (
            <Pressable
              key={deck.id}
              accessibilityRole="button"
              accessibilityLabel={`${deck.name}, ${cards} cards`}
              onPress={() => {
                haptic.tap();
                router.push(`/deck/${deck.id}`);
              }}
              style={({ pressed }) => [styles.deck, pressed && { opacity: 0.85 }]}
            >
              <View style={[styles.swatch, { backgroundColor: deck.color }]} />
              <View style={{ flex: 1, gap: 4 }}>
                <Txt variant="heading" numberOfLines={1}>{deck.name}</Txt>
                <Txt variant="small" color="textDim">
                  {cards} card{cards === 1 ? '' : 's'}
                  {counts.total > 0 ? `, ${counts.total} ready` : ''}
                </Txt>
              </View>
              {counts.total > 0 ? (
                <Button title="Review" variant="ghost" tint={deck.color} onPress={() => router.push(`/review/${deck.id}`)} />
              ) : (
                <Ionicons name="chevron-forward" size={18} color={colors.textFaint} />
              )}
            </Pressable>
          ))}
        </View>
      )}

      <NewDeckSheet visible={creating} onClose={() => setCreating(false)} />
    </Screen>
  );
}

function Count({ label, value }: { label: string; value: number }) {
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <Txt variant="title">{value}</Txt>
      <Txt variant="caption" color="textDim">{label}</Txt>
    </View>
  );
}

function NewDeckSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const [name, setName] = useState('');
  const [color, setColor] = useState(DECK_COLORS[0]);

  const create = () => {
    const id = actions.addDeck(name, color);
    if (!id) return;
    setName('');
    onClose();
    router.push(`/deck/${id}`);
  };

  return (
    <Sheet visible={visible} onClose={onClose} title="New deck">
      <TextField label="Name" placeholder="Spanish verbs, Cell biology..." value={name} onChangeText={setName} autoFocus maxLength={50} returnKeyType="done" onSubmitEditing={create} />
      <View style={{ gap: space.sm }}>
        <Txt variant="small" color="textDim">Color</Txt>
        <View style={{ flexDirection: 'row', gap: space.md }}>
          {DECK_COLORS.map((c) => (
            <Pressable
              key={c}
              accessibilityRole="button"
              accessibilityLabel={`Color ${c}`}
              accessibilityState={{ selected: c === color }}
              onPress={() => setColor(c)}
              style={[styles.colorDot, { backgroundColor: c }, c === color && styles.colorSelected]}
            />
          ))}
        </View>
      </View>
      <Button title="Create deck" tint={areaColor.recall} size="lg" disabled={!name.trim()} onPress={create} />
    </Sheet>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  countRow: { flexDirection: 'row' },
  deck: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.md,
  },
  swatch: { width: 6, alignSelf: 'stretch', borderRadius: 3 },
  colorDot: { width: 34, height: 34, borderRadius: 17, borderWidth: 2, borderColor: 'transparent' },
  colorSelected: { borderColor: colors.text },
});
