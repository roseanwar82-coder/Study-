import { Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { DRILLS, DRILL_ORDER } from '@/core/drills';
import { recommendedDrill } from '@/core/stats';
import { haptic } from '@/services/haptics';
import { useApp } from '@/store';
import { Screen } from '@/ui/Layout';
import { Txt } from '@/ui/Text';
import { areaColor, colors, radius, space } from '@/ui/theme';

export default function Drills() {
  const stats = useApp((s) => s.drills.stats);
  const levels = useApp((s) => s.drills.levels);
  const suggested = useApp((s) => recommendedDrill(s));

  return (
    <Screen>
      <View style={{ gap: 4 }}>
        <Txt variant="display">Drills</Txt>
        <Txt color="textDim">Short exercises for attention, memory and reasoning. Two minutes is plenty.</Txt>
      </View>

      <View style={{ gap: space.md }}>
        {DRILL_ORDER.map((kind) => {
          const meta = DRILLS[kind];
          const st = stats[kind];
          const level = levels[kind];
          const levelLabel = meta.levels.find((l) => l.value === level)?.label;
          return (
            <Pressable
              key={kind}
              accessibilityRole="button"
              accessibilityLabel={`${meta.title}, ${meta.domain}`}
              onPress={() => {
                haptic.tap();
                router.push(`/drill/${kind}`);
              }}
              style={({ pressed }) => [styles.card, kind === suggested && { borderColor: areaColor.drills + '88' }, pressed && { opacity: 0.85 }]}
            >
              <View style={styles.topRow}>
                <Txt variant="caption" style={{ color: areaColor.drills, fontWeight: '700', letterSpacing: 1 }}>{meta.domain.toUpperCase()}</Txt>
                {kind === suggested ? <Txt variant="caption" color="textDim">Suggested today</Txt> : null}
              </View>
              <Txt variant="title">{meta.title}</Txt>
              <Txt variant="small" color="textDim">{meta.blurb}</Txt>
              <View style={styles.bottomRow}>
                <Txt variant="small" color="textDim">
                  {st ? `Best ${st.best}. Played ${st.plays} time${st.plays === 1 ? '' : 's'}.` : 'Not played yet'}
                </Txt>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  {levelLabel && meta.levels.length > 1 ? <Txt variant="caption" color="textFaint">{meta.levelName} {levelLabel}</Txt> : null}
                  <Ionicons name="chevron-forward" size={18} color={colors.textFaint} />
                </View>
              </View>
            </Pressable>
          );
        })}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: {
    gap: 6,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.lg,
  },
  topRow: { flexDirection: 'row', justifyContent: 'space-between' },
  bottomRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: space.sm },
});
