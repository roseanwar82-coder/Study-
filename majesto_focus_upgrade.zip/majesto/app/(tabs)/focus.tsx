import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import type { AppState } from '@/core/types';
import { elapsedMs, isExpired, remainingMs } from '@/core/focus';
import { guardFromSettings, missingForGuard } from '@/core/guard';
import type { GuardConfig } from '@/core/types';
import { todayTasks } from '@/core/stats';
import { MINUTE, dayKey, formatClock, formatMinutes, formatTimeOfDay } from '@/core/time';
import { focusGuard } from '@/services/focusGuard';
import { haptic } from '@/services/haptics';
import { cancelTimerEnd, scheduleTimerEnd } from '@/services/notifications';
import { actions, useApp } from '@/store';
import type { FinishResult } from '@/store/actions';
import { Button } from '@/ui/Button';
import { useBlockedAttempts } from '@/ui/guardHooks';
import { useNow } from '@/ui/hooks';
import { Stepper, TextField, ToggleRow } from '@/ui/Inputs';
import { Card, Chip, Screen, SectionHeader } from '@/ui/Layout';
import { Rings } from '@/ui/Progress';
import { Txt } from '@/ui/Text';
import { areaColor, colors, space } from '@/ui/theme';

const PRESETS = [15, 25, 45, 60, 90];

export default function Focus() {
  const state = useApp((s) => s);
  const timer = state.timer;
  const running = !!timer && timer.pausedAt === null;
  const now = useNow(running);

  const [minutes, setMinutes] = useState(state.settings.focusMin);
  const [taskId, setTaskId] = useState<string | null>(null);
  const [label, setLabel] = useState('');
  const [result, setResult] = useState<FinishResult | null>(null);

  const finish = useCallback((completed: boolean) => {
    cancelTimerEnd();
    const res = actions.finishTimer(completed);
    if (res) {
      haptic.success();
      setResult(res);
    }
  }, []);

  // The clock ran out (or ran out while the app was closed).
  const expired = timer ? isExpired(timer, now) : false;
  useEffect(() => {
    if (expired) finish(true);
  }, [expired, finish]);

  const start = (kind: 'focus' | 'break', mins: number, guard: GuardConfig | null = null) => {
    setResult(null);
    actions.startTimer({ kind, minutes: mins, taskId: kind === 'focus' ? taskId : null, label: kind === 'focus' ? label : '', guard });
    scheduleTimerEnd(mins * 60, kind);
  };

  /** Starts a focus block, with the Android focus guard when it is on. Explains anything still missing first. */
  const startFocus = (mins: number) => {
    const guard = focusGuard.isSupported ? guardFromSettings(state.settings) : null;
    if (!guard) return start('focus', mins);
    const missing = missingForGuard(guard, focusGuard.getPermissions());
    if (missing.length === 0) return start('focus', mins, guard);
    Alert.alert(
      'Finish setting up focus guard?',
      `Still needed:\n${missing.map((m) => `- ${m.title}: ${m.why}`).join('\n')}\n\nYou can start now, but those parts will be off.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Set up', onPress: () => router.push('/focus-guard') },
        { text: 'Start anyway', onPress: () => start('focus', mins, guard) },
      ],
    );
  };

  const confirmEnd = () => {
    if (!timer) return;
    const mins = elapsedMs(timer, Date.now()) / MINUTE;
    if (timer.kind === 'break') return finish(false);
    Alert.alert(
      'End this session?',
      mins < 1 ? 'Less than a minute has passed, so nothing will be logged.' : `The ${formatMinutes(mins * MINUTE)} so far will be logged.`,
      [
        { text: 'Keep going', style: 'cancel' },
        { text: 'End session', style: 'destructive', onPress: () => finish(false) },
      ],
    );
  };

  const guardOn = !!timer?.guard;
  const blockedAttempts = useBlockedAttempts(guardOn);

  const confirmDiscard = () => {
    Alert.alert('Discard this session?', 'Nothing will be logged.', [
      { text: 'Keep going', style: 'cancel' },
      {
        text: 'Discard',
        style: 'destructive',
        onPress: () => {
          cancelTimerEnd();
          actions.discardTimer();
        },
      },
    ]);
  };

  if (timer) {
    const remaining = remainingMs(timer, now);
    const ratio = elapsedMs(timer, now) / timer.plannedMs;
    const paused = timer.pausedAt !== null;
    const isBreak = timer.kind === 'break';
    const tint = isBreak ? areaColor.recall : areaColor.focus;
    const task = state.tasks.find((t) => t.id === timer.taskId);

    return (
      <Screen scroll={false} contentStyle={{ alignItems: 'center', justifyContent: 'center', gap: space.xl }}>
        <Txt variant="small" color="textDim">{isBreak ? 'Break' : paused ? 'Paused' : 'Focusing'}</Txt>
        <Rings size={280} stroke={12} rings={[{ ratio, color: tint }]}>
          <Txt variant="numeral" style={paused ? { color: colors.textDim } : undefined}>{formatClock(remaining)}</Txt>
          {!isBreak && (task || timer.label) ? (
            <Txt variant="small" color="textDim" numberOfLines={2} style={{ maxWidth: 190, textAlign: 'center' }}>
              {task?.title ?? timer.label}
            </Txt>
          ) : null}
        </Rings>
        <View style={styles.controls}>
          {paused ? (
            <Button
              title="Resume"
              icon="play"
              tint={tint}
              size="lg"
              onPress={() => {
                actions.resumeTimer();
                scheduleTimerEnd(remaining / 1000, timer.kind);
              }}
            />
          ) : (
            <Button
              title="Pause"
              icon="pause"
              variant="secondary"
              size="lg"
              onPress={() => {
                cancelTimerEnd();
                actions.pauseTimer();
              }}
            />
          )}
          {!isBreak ? (
            <Button
              title={timer.distractions > 0 ? `Distracted (${timer.distractions})` : 'Distracted'}
              variant="secondary"
              size="lg"
              onPress={() => {
                haptic.warn();
                actions.addDistraction();
              }}
            />
          ) : null}
        </View>
        {guardOn ? (
          <Txt variant="small" color="textDim">
            Focus guard on{blockedAttempts > 0 ? `. ${blockedAttempts} blocked attempt${blockedAttempts === 1 ? '' : 's'}` : ''}
          </Txt>
        ) : null}
        {!isBreak ? <Button title="Ask AI" icon="sparkles-outline" variant="ghost" tint={tint} onPress={() => router.push('/assist')} /> : null}
        <View style={styles.controls}>
          <Button title={isBreak ? 'Skip break' : 'End session'} variant="ghost" tint={tint} onPress={confirmEnd} />
          {!isBreak ? <Button title="Discard" variant="danger" onPress={confirmDiscard} /> : null}
        </View>
      </Screen>
    );
  }

  return (
    <IdleView
      state={state}
      minutes={minutes}
      setMinutes={setMinutes}
      taskId={taskId}
      setTaskId={setTaskId}
      label={label}
      setLabel={setLabel}
      result={result}
      dismissResult={() => setResult(null)}
      onStart={start}
      onStartFocus={startFocus}
    />
  );
}

function IdleView({ state, minutes, setMinutes, taskId, setTaskId, label, setLabel, result, dismissResult, onStart, onStartFocus }: {
  state: AppState;
  minutes: number;
  setMinutes: (m: number) => void;
  taskId: string | null;
  setTaskId: (id: string | null) => void;
  label: string;
  setLabel: (v: string) => void;
  result: FinishResult | null;
  dismissResult: () => void;
  onStart: (kind: 'focus' | 'break', mins: number) => void;
  onStartFocus: (mins: number) => void;
}) {
  const today = dayKey(Date.now());
  const openTasks = useMemo(() => todayTasks(state, today).filter((t) => !t.doneAt), [state, today]);
  const sessions = useMemo(() => state.sessions.filter((s) => s.dayKey === today).slice().reverse().slice(0, 6), [state.sessions, today]);
  const breakMin = state.settings.breakMin;

  // If the chosen task was finished or deleted, fall back to "no task".
  useEffect(() => {
    if (taskId && !openTasks.some((t) => t.id === taskId)) setTaskId(null);
  }, [taskId, openTasks, setTaskId]);

  return (
    <Screen>
      <Txt variant="display">Focus</Txt>

      {result ? (
        <Card tint={result.kind === 'break' ? areaColor.recall : areaColor.focus} style={{ gap: space.md }}>
          {result.kind === 'break' ? (
            <>
              <Txt variant="title">Break over</Txt>
              <Txt color="textDim">Ready for another block?</Txt>
              <Button title={`Start ${minutes} minute block`} onPress={() => onStartFocus(minutes)} />
            </>
          ) : result.session ? (
            <>
              <Txt variant="title">{result.session.completed ? 'Block complete' : 'Session logged'}</Txt>
              <Txt color="textDim">
                {formatMinutes(result.session.actualMs)} focused
                {result.session.distractions > 0 ? `, ${result.session.distractions} distraction${result.session.distractions === 1 ? '' : 's'}` : ''}
                . +{result.xp} XP
              </Txt>
              <View style={styles.controls}>
                <Button title={`Take a ${breakMin} minute break`} tint={areaColor.recall} onPress={() => onStart('break', breakMin)} />
                <Button title="Done" variant="ghost" onPress={dismissResult} />
              </View>
            </>
          ) : (
            <>
              <Txt variant="title">Too short to log</Txt>
              <Txt color="textDim">Sessions need at least a minute to count.</Txt>
              <Button title="Dismiss" variant="ghost" onPress={dismissResult} />
            </>
          )}
        </Card>
      ) : null}

      <Card style={{ gap: space.lg }}>
        <View style={{ alignItems: 'center', gap: 2 }}>
          <Txt variant="numeral">{formatClock(minutes * MINUTE)}</Txt>
          <Txt variant="small" color="textDim">One block</Txt>
        </View>
        <View style={styles.chips}>
          {PRESETS.map((m) => (
            <Chip key={m} label={`${m}m`} selected={minutes === m} onPress={() => setMinutes(m)} />
          ))}
        </View>
        <Stepper label="Custom length" value={minutes} min={5} max={180} step={5} onChange={setMinutes} format={(v) => `${v} min`} />
      </Card>

      <View style={{ gap: space.md }}>
        <SectionHeader title="Working on" />
        <View style={styles.chips}>
          <Chip label="Nothing specific" selected={taskId === null} onPress={() => setTaskId(null)} />
          {openTasks.map((t) => (
            <Chip key={t.id} label={t.title.length > 28 ? `${t.title.slice(0, 27)}...` : t.title} selected={taskId === t.id} onPress={() => setTaskId(t.id)} />
          ))}
        </View>
        {taskId === null ? (
          <TextField placeholder="Add a note (optional)" value={label} onChangeText={setLabel} maxLength={80} returnKeyType="done" />
        ) : null}
      </View>

      {focusGuard.isSupported ? (
        <Card style={{ gap: space.sm }}>
          <ToggleRow
            label="Focus guard"
            hint={
              state.settings.blockedApps.length > 0
                ? `Floating timer, ${state.settings.blockedApps.length} blocked app${state.settings.blockedApps.length === 1 ? '' : 's'}`
                : 'Floating timer and app blocking'
            }
            value={state.settings.guardEnabled}
            onChange={(v) => actions.updateSettings({ guardEnabled: v })}
          />
          <Button title="Set up focus guard" variant="ghost" onPress={() => router.push('/focus-guard')} />
        </Card>
      ) : null}

      <Button title="Start focus" icon="play" size="lg" onPress={() => onStartFocus(minutes)} />
      <Button title="Ask AI" icon="sparkles-outline" variant="secondary" onPress={() => router.push('/assist')} />

      <View style={{ gap: space.md }}>
        <SectionHeader title="Today's sessions" />
        {sessions.length === 0 ? (
          <Txt variant="small" color="textDim">Nothing logged yet. Your first block will show up here.</Txt>
        ) : (
          <View style={styles.list}>
            {sessions.map((s, i) => {
              const task = state.tasks.find((t) => t.id === s.taskId);
              return (
                <View key={s.id} style={[styles.sessionRow, i > 0 && styles.divider]}>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Txt style={{ fontWeight: '600' }}>{formatMinutes(s.actualMs)}{s.completed ? '' : ' (ended early)'}</Txt>
                    <Txt variant="caption" color="textDim" numberOfLines={1}>
                      {formatTimeOfDay(s.startedAt)}{task ? `, ${task.title}` : s.label ? `, ${s.label}` : ''}
                    </Txt>
                  </View>
                  <Txt variant="small" color="textDim">+{s.xp} XP</Txt>
                </View>
              );
            })}
          </View>
        )}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  controls: { flexDirection: 'row', gap: space.md, flexWrap: 'wrap', justifyContent: 'center' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  list: { backgroundColor: colors.surface, borderRadius: 16, borderWidth: 1, borderColor: colors.border, paddingHorizontal: space.lg },
  sessionRow: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingVertical: space.md },
  divider: { borderTopWidth: 1, borderTopColor: colors.border },
});
