import { useEffect, useState } from 'react';
import { Linking, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { normalizeEndpoint } from '@/core/ai';
import type { DndMode } from '@/core/types';
import { checkBackend } from '@/services/ai';
import { focusGuard, type PermissionKind } from '@/services/focusGuard';
import { actions, useApp } from '@/store';
import { Button } from '@/ui/Button';
import { useGuardPermissions } from '@/ui/guardHooks';
import { TextField, ToggleRow } from '@/ui/Inputs';
import { Card, Chip, IconButton, Screen, SectionHeader } from '@/ui/Layout';
import { Txt } from '@/ui/Text';
import { colors, space } from '@/ui/theme';

const DND_OPTIONS: { mode: DndMode; label: string; hint: string }[] = [
  { mode: 'off', label: 'Leave alone', hint: 'Majesto does not touch your notification settings.' },
  { mode: 'priority', label: 'Priority only', hint: 'Do Not Disturb with your priority people and apps still allowed.' },
  { mode: 'alarms', label: 'Alarms only', hint: 'Everything is silenced except alarms. Timer alerts from Majesto are silenced too.' },
];

export default function FocusGuardSettings() {
  const settings = useApp((s) => s.settings);
  const { permissions, refresh } = useGuardPermissions();
  const supported = focusGuard.isSupported;
  const [endpoint, setEndpoint] = useState(settings.aiEndpoint);
  const [check, setCheck] = useState<{ ok: boolean; message: string } | null>(null);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    setCheck(null);
  }, [endpoint]);

  const saveEndpoint = () => {
    const clean = endpoint.trim();
    if (clean === '' || normalizeEndpoint(clean)) actions.updateSettings({ aiEndpoint: clean.replace(/\/+$/, '') });
  };

  const runCheck = async () => {
    saveEndpoint();
    setChecking(true);
    setCheck(await checkBackend(endpoint.trim() || process.env.EXPO_PUBLIC_AI_ENDPOINT || null));
    setChecking(false);
  };

  const grant = (kind: PermissionKind) => {
    if (!focusGuard.openSettings(kind)) Linking.openSettings().catch(() => {});
    refresh();
  };

  const endpointInvalid = endpoint.trim() !== '' && !normalizeEndpoint(endpoint);

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={styles.top}>
        <IconButton icon="chevron-back" label="Back" color={colors.text} onPress={() => router.back()} />
      </View>
      <View style={{ gap: 6 }}>
        <Txt variant="display">Focus guard</Txt>
        <Txt color="textDim">
          Turn a focus block into a protected one: a floating timer over your study app, distracting apps covered while the clock runs, and optional Do Not Disturb.
        </Txt>
      </View>

      {!supported ? (
        <Card tint={colors.gold}>
          <Txt style={{ fontWeight: '700' }}>Android build needed</Txt>
          <Txt variant="small" color="textDim" style={{ marginTop: 4 }}>
            The floating timer and app blocking only exist in the Android app built from this project. They are not available on iPhone or in Expo Go. AI help below still works with typed questions and uploaded pictures.
          </Txt>
        </Card>
      ) : null}

      {supported ? (
        <>
          <View style={{ gap: space.md }}>
            <SectionHeader title="Focus blocks" />
            <Card style={{ gap: space.md }}>
              <ToggleRow
                label="Use focus guard"
                hint="Applies to every focus block you start. Breaks are never guarded."
                value={settings.guardEnabled}
                onChange={(v) => actions.updateSettings({ guardEnabled: v })}
              />
              <Divider />
              <View style={styles.row}>
                <View style={{ flex: 1, gap: 2 }}>
                  <Txt>Apps to block</Txt>
                  <Txt variant="caption" color="textDim">
                    {settings.blockedApps.length === 0 ? 'None chosen yet' : `${settings.blockedApps.length} chosen`}
                  </Txt>
                </View>
                <Button title="Choose apps" variant="secondary" onPress={() => router.push('/blocked-apps')} />
              </View>
              <Divider />
              <ToggleRow
                label="Floating timer"
                hint="A small movable pill with the time left. Tap it for pause, stop and AI help."
                value={settings.floatingTimer}
                onChange={(v) => actions.updateSettings({ floatingTimer: v })}
              />
            </Card>
          </View>

          <View style={{ gap: space.md }}>
            <SectionHeader title="Notifications" />
            <Card style={{ gap: space.md }}>
              <Txt variant="small" color="textDim">
                Uses Android's Do Not Disturb. Majesto never reads your notifications. Your earlier Do Not Disturb setting is put back when the block ends.
              </Txt>
              <View style={styles.chips}>
                {DND_OPTIONS.map((o) => (
                  <Chip key={o.mode} label={o.label} selected={settings.dndMode === o.mode} onPress={() => actions.updateSettings({ dndMode: o.mode })} />
                ))}
              </View>
              <Txt variant="caption" color="textDim">{DND_OPTIONS.find((o) => o.mode === settings.dndMode)?.hint}</Txt>
            </Card>
          </View>

          <View style={{ gap: space.md }}>
            <SectionHeader title="Permissions" />
            <Card style={{ gap: space.lg }}>
              <Permission
                title="Display over other apps"
                granted={permissions.overlay}
                why="Needed for the floating timer and for the screen that covers a blocked app."
                onGrant={() => grant('overlay')}
              />
              <Divider />
              <Permission
                title="Usage access"
                granted={permissions.usageAccess}
                why="Lets Majesto see which app is in front, so it can cover the apps you chose. It reads app names only, not what is inside them."
                onGrant={() => grant('usageAccess')}
              />
              <Divider />
              <Permission
                title="Accessibility (optional, faster)"
                granted={permissions.accessibility}
                why="An alternative to Usage access that reacts instantly. Majesto's service listens only for 'a new app window opened' and cannot read your screen, taps or typing. Turn it on under Installed apps, Majesto focus guard."
                onGrant={() => grant('accessibility')}
              />
              <Divider />
              <Permission
                title="Do Not Disturb access"
                granted={permissions.notificationPolicy}
                why="Only needed if you picked Priority only or Alarms only above."
                onGrant={() => grant('notificationPolicy')}
              />
              <Divider />
              <Permission
                title="Notifications"
                granted={permissions.notifications}
                why="Android shows a small notification while a protected block runs. Without it the block still works."
                onGrant={() => grant('notifications')}
              />
            </Card>
            <Txt variant="caption" color="textDim">
              You need "Display over other apps" plus either Usage access or Accessibility to block apps. Majesto never turns any of these on by itself. You can switch them off in Android Settings at any time.
            </Txt>
          </View>

          <Card style={{ gap: 6 }}>
            <Txt style={{ fontWeight: '700' }}>What this can and cannot do</Txt>
            <Txt variant="small" color="textDim">
              Android does not let an app close or freeze other apps. Majesto covers a blocked app with a full-screen reminder as soon as it notices it, so a blocked app may flash for a moment. Your phone, settings, home screen and Majesto are never blocked. Pausing the timer pauses blocking too. If you restart the phone during a block, open Majesto and it picks the block up again.
            </Txt>
          </Card>
        </>
      ) : null}

      <View style={{ gap: space.md }}>
        <SectionHeader title="AI help" />
        <Card style={{ gap: space.md }}>
          <Txt variant="small" color="textDim">
            AI help sends the question or picture you choose to a small server you run, which asks the AI provider. The provider key never lives in the app. Setup steps are in backend/README.md.
          </Txt>
          <TextField
            label="Backend address"
            placeholder="https://your-backend.example.com"
            value={endpoint}
            onChangeText={setEndpoint}
            onBlur={saveEndpoint}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            returnKeyType="done"
          />
          {endpointInvalid ? <Txt variant="caption" style={{ color: colors.danger }}>The address must start with https://</Txt> : null}
          {!endpoint.trim() && process.env.EXPO_PUBLIC_AI_ENDPOINT ? (
            <Txt variant="caption" color="textDim">Using the address this build was made with.</Txt>
          ) : null}
          <Button title="Check connection" variant="secondary" loading={checking} onPress={runCheck} />
          {check ? <Txt variant="small" style={{ color: check.ok ? colors.success : colors.danger }}>{check.message}</Txt> : null}
          <Button title="Open AI help" icon="sparkles-outline" onPress={() => router.push('/assist')} />
        </Card>
      </View>
    </Screen>
  );
}

function Permission({ title, why, granted, onGrant }: { title: string; why: string; granted: boolean; onGrant: () => void }) {
  return (
    <View style={{ gap: 6 }}>
      <View style={styles.row}>
        <Txt style={{ flex: 1, fontWeight: '600' }}>{title}</Txt>
        <Txt variant="caption" style={{ color: granted ? colors.success : colors.textDim, fontWeight: '700' }}>
          {granted ? 'Granted' : 'Not granted'}
        </Txt>
      </View>
      <Txt variant="caption" color="textDim">{why}</Txt>
      {!granted ? <Button title="Open Android settings" variant="secondary" onPress={onGrant} /> : null}
    </View>
  );
}

const Divider = () => <View style={{ height: 1, backgroundColor: colors.border }} />;

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
});
