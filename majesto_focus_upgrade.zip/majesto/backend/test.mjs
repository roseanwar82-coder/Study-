import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createHandler, loadConfig, parseRequest, toProviderMessages } from './server.mjs';

const img = { mediaType: 'image/png', base64: 'iVBORw0KGgo=' };

async function boot(env = {}, upstream) {
  const calls = [];
  const fakeUpstream = http.createServer(async (req, res) => {
    let b = '';
    for await (const c of req) b += c;
    calls.push({ headers: req.headers, url: req.url, body: JSON.parse(b) });
    const r = upstream ? upstream(calls.length) : { status: 200, body: { modelVersion: 'g', candidates: [{ content: { parts: [{ text: 'x = 4' }] } }] } };
    res.writeHead(r.status, { 'content-type': 'application/json', ...(r.headers ?? {}) });
    res.end(JSON.stringify(r.body));
  });
  await new Promise((r) => fakeUpstream.listen(0, r));
  const cfg = loadConfig({ GEMINI_API_KEY: 'k', GEMINI_BASE_URL: `http://127.0.0.1:${fakeUpstream.address().port}`, ...env });
  const app = http.createServer(createHandler(cfg));
  await new Promise((r) => app.listen(0, r));
  const base = `http://127.0.0.1:${app.address().port}`;
  const post = (body, headers = {}) =>
    fetch(`${base}/solve`, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body) });
  return { base, post, calls, close: () => { app.close(); fakeUpstream.close(); } };
}

const ask = (text = 'Solve 2x = 8', extra = {}) => ({ detail: 'brief', messages: [{ role: 'user', text, ...extra }] });

test('health reports whether a key is configured', async () => {
  const s = await boot();
  assert.deepEqual(await (await fetch(`${s.base}/health`)).json(), { ok: true, configured: true });
  s.close();
  const s2 = await boot({ GEMINI_API_KEY: '' });
  assert.equal((await (await fetch(`${s2.base}/health`)).json()).configured, false);
  s2.close();
});

test('a question reaches the provider with the key and tutor prompt, and the answer comes back', async () => {
  const s = await boot();
  const res = await s.post(ask('Solve 2x = 8', { image: img }));
  assert.equal(res.status, 200);
  assert.equal((await res.json()).answer, 'x = 4');
  const c = s.calls[0];
  assert.equal(c.headers['x-goog-api-key'], 'k');
  assert.equal(c.url, '/v1beta/models/gemini-2.5-flash:generateContent');
  assert.match(c.body.systemInstruction.parts[0].text, /patient, efficient academic tutor/);
  assert.match(c.body.systemInstruction.parts[0].text, /concise/);
  assert.equal(c.body.contents[0].role, 'user');
  assert.equal(c.body.contents[0].parts[0].inlineData.mimeType, 'image/png');
  assert.equal(c.body.contents[0].parts[1].text, 'Solve 2x = 8');
  s.close();
});

test('detailed mode asks for more room', async () => {
  const s = await boot();
  await s.post({ ...ask(), detail: 'detailed' });
  assert.equal(s.calls[0].body.generationConfig.maxOutputTokens, 4096);
  assert.match(s.calls[0].body.systemInstruction.parts[0].text, /fuller explanation/);
  s.close();
});

test('bad requests are refused before any provider call', async () => {
  const s = await boot();
  assert.equal((await s.post('not json')).status, 400);
  assert.equal((await s.post({ messages: [] })).status, 400);
  assert.equal((await s.post(ask('   '))).status, 400);
  assert.equal((await s.post(ask('x'.repeat(6001)))).status, 413);
  const bad = await s.post(ask('q', { image: { mediaType: 'image/gif', base64: 'AAAA' } }));
  assert.equal(bad.status, 400);
  assert.equal((await bad.json()).error.code, 'bad_image');
  assert.equal((await s.post({ messages: [{ role: 'assistant', text: 'hi' }] })).status, 400);
  assert.equal((await s.post({ messages: [{ role: 'user', text: 'a' }, { role: 'user', text: 'b' }] })).status, 400);
  assert.equal(s.calls.length, 0);
  s.close();
});

test('an access token is enforced when configured', async () => {
  const s = await boot({ APP_TOKEN: 'secret' });
  assert.equal((await s.post(ask())).status, 401);
  assert.equal((await s.post(ask(), { 'x-majesto-token': 'wrong' })).status, 401);
  assert.equal((await s.post(ask(), { 'x-majesto-token': 'secret' })).status, 200);
  s.close();
});

test('no key means an honest 503, never a made-up answer', async () => {
  const s = await boot({ GEMINI_API_KEY: '' });
  const res = await s.post(ask());
  assert.equal(res.status, 503);
  assert.equal((await res.json()).error.code, 'not_configured');
  s.close();
});

test('rate limiting kicks in per client', async () => {
  const s = await boot({ RATE_LIMIT: '2' });
  assert.equal((await s.post(ask())).status, 200);
  assert.equal((await s.post(ask())).status, 200);
  const third = await s.post(ask());
  assert.equal(third.status, 429);
  assert.ok(Number(third.headers.get('retry-after')) > 0);
  s.close();
});

test('provider failures become clear, safe errors', async () => {
  const cases = [
    [{ status: 429, body: { error: { message: 'slow' } }, headers: { 'retry-after': '7' } }, 429, 'rate_limited'],
    [{ status: 400, body: { error: { message: 'API key not valid. Please pass a valid API key.' } } }, 502, 'upstream_auth'],
    [{ status: 403, body: { error: { message: 'denied' } } }, 502, 'upstream_auth'],
    [{ status: 200, body: { promptFeedback: { blockReason: 'SAFETY' } } }, 422, 'blocked'],
    [{ status: 404, body: { error: { message: 'model' } } }, 502, 'upstream_model'],
    [{ status: 400, body: { error: { message: 'Unable to process input image' } } }, 400, 'bad_image'],
    [{ status: 500, body: { error: { message: 'secret internals' } } }, 502, 'upstream'],
    [{ status: 200, body: { candidates: [{ content: { parts: [] } }] } }, 502, 'empty'],
  ];
  for (const [up, status, code] of cases) {
    const s = await boot({}, () => up);
    const res = await s.post(ask());
    const body = await res.json();
    assert.equal(res.status, status, code);
    assert.equal(body.error.code, code);
    assert.ok(!JSON.stringify(body).includes('secret internals'));
    s.close();
  }
});

test('conversation images and roles map to provider messages', () => {
  const parsed = parseRequest({
    detail: 'brief',
    messages: [
      { role: 'user', text: 'what is this', image: img },
      { role: 'assistant', text: 'a graph' },
      { role: 'user', text: 'explain more' },
    ],
  });
  const out = toProviderMessages(parsed.messages);
  assert.deepEqual(out.map((m) => m.role), ['user', 'model', 'user']);
  assert.equal(out[0].parts.length, 2);
  assert.equal(out[2].parts.length, 1);
});

test('unknown routes are 404', async () => {
  const s = await boot();
  assert.equal((await fetch(`${s.base}/nope`)).status, 404);
  s.close();
});
