# Majesto AI backend

A tiny server (no dependencies, Node 18+) that sits between the app and the AI provider. **The provider key lives here, never in the APK.**

The app sends `POST /solve` with the conversation (and optionally one picture). The server adds the tutor instructions, calls the Google Gemini API and returns `{ "answer": "..." }`. If anything is missing or fails, the app shows an honest error. Nothing is ever faked.

## Configure

| Variable | Required | Meaning |
| --- | --- | --- |
| `GEMINI_API_KEY` | yes | Your key from aistudio.google.com/apikey. Free-tier limits or billing apply to your Google account. |
| `GEMINI_MODEL` | no | Model id. Default `gemini-2.5-flash`. Must accept images to read pictures. |
| `APP_TOKEN` | no | If set, requests need header `x-majesto-token: <value>`. Put the same value in `EXPO_PUBLIC_AI_TOKEN` when building the app. It ends up inside the APK, so treat it as a speed bump, not a secret. |
| `RATE_LIMIT` / `RATE_WINDOW_SEC` | no | Requests per client per window. Default 30 per 600 s. |
| `PORT` | no | Default 8787. |
| `TRUST_PROXY` | no | Set to `1` behind a proxy that sets `x-forwarded-for`, so rate limits are per user. |

## Run locally

```bash
cd backend
GEMINI_API_KEY=your-key node server.mjs
curl localhost:8787/health          # {"ok":true,"configured":true}
```

From the Android emulator the address is `http://10.0.2.2:8787`. A real phone needs a public **https** address (plain http is only accepted for local development addresses).

## Deploy (you choose and pay; nothing here deploys for you)

Any host that runs Node works, for example Render, Railway, Fly.io or a small VPS: set the start command to `node backend/server.mjs`, add the variables above, and use the https address it gives you.

## Connect the app

Either open the app, Profile, Focus guard & AI help, and paste the address under "Backend address", then press "Check connection"; or build with `EXPO_PUBLIC_AI_ENDPOINT=https://...` (and optionally `EXPO_PUBLIC_AI_TOKEN`) in your environment or `.env`.

## Test

```bash
npm run test:backend
```
