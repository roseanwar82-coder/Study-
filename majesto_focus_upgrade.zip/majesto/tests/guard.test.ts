import test from 'node:test';
import assert from 'node:assert/strict';
import { createTimer, pauseTimer } from '@/core/focus';
import {
  EMPTY_NATIVE_SESSION, formatHms, guardFromSettings, missingForGuard, reconcileGuard, timerToNative,
  type GuardPermissions, type NativeSession,
} from '@/core/guard';
import type { GuardConfig } from '@/core/types';
import { migrate } from '@/store/state';
import { makeApp } from './helpers';

const T0 = 1_000_000_000_000;
const MIN = 60_000;
const cfg: GuardConfig = { blockedApps: ['com.instagram.android'], floatingTimer: true, dndMode: 'off' };
const guarded = () => createTimer({ kind: 'focus', minutes: 25, guard: cfg }, T0, 't1');
const nativeFor = (t: ReturnType<typeof guarded>, extra: Partial<NativeSession> = {}): NativeSession => ({
  ...EMPTY_NATIVE_SESSION, active: true, id: t.id, startedAt: t.startedAt, plannedMs: t.plannedMs,
  pausedAt: t.pausedAt, pausedTotalMs: t.pausedTotalMs, ...extra,
});
const allPerms: GuardPermissions = { overlay: true, usageAccess: true, accessibility: false, notificationPolicy: true, notifications: true };

/* ---------- timer + settings ---------- */

test('guard config is only stored on focus timers', () => {
  assert.deepEqual(createTimer({ kind: 'focus', minutes: 25, guard: cfg }, T0, 'a').guard, cfg);
  assert.equal(createTimer({ kind: 'break', minutes: 5, guard: cfg }, T0, 'b').guard, undefined);
  assert.equal('guard' in createTimer({ kind: 'focus', minutes: 25 }, T0, 'c'), false);
});

test('guardFromSettings returns null when off or when there is nothing to do', () => {
  const base = { guardEnabled: true, blockedApps: [], floatingTimer: false, dndMode: 'off' as const };
  assert.equal(guardFromSettings({ ...base, guardEnabled: false, floatingTimer: true }), null);
  assert.equal(guardFromSettings(base), null);
  assert.deepEqual(guardFromSettings({ ...base, blockedApps: ['a', 'a', 'b'] }), { blockedApps: ['a', 'b'], floatingTimer: false, dndMode: 'off' });
});

test('old saves without guard settings load with safe defaults, bad values are repaired', () => {
  const old = migrate({ version: 1, settings: { focusMin: 40 } }, T0, (p = 'id') => p);
  assert.equal(old.settings.focusMin, 40);
  assert.equal(old.settings.guardEnabled, false);
  assert.deepEqual(old.settings.blockedApps, []);
  assert.equal(old.settings.floatingTimer, true);
  assert.equal(old.settings.dndMode, 'off');

  const bad = migrate({ version: 1, settings: { blockedApps: 'nope', dndMode: 'loud', guardEnabled: 'yes' } }, T0, (p = 'id') => p);
  assert.deepEqual(bad.settings.blockedApps, []);
  assert.equal(bad.settings.dndMode, 'off');
  assert.equal(bad.settings.guardEnabled, false);

  const dupes = migrate({ version: 1, settings: { blockedApps: ['a', 'a', 3, '', 'b'] } }, T0, (p = 'id') => p);
  assert.deepEqual(dupes.settings.blockedApps, ['a', 'b']);
});

/* ---------- permissions ---------- */

test('missingForGuard lists only what the chosen features need', () => {
  const none = { overlay: false, usageAccess: false, accessibility: false, notificationPolicy: false, notifications: true };
  assert.deepEqual(missingForGuard(cfg, allPerms), []);
  assert.deepEqual(missingForGuard(cfg, none).map((m) => m.key), ['overlay', 'detection']);
  assert.deepEqual(missingForGuard({ ...cfg, floatingTimer: false, blockedApps: [] }, none), []);
  assert.deepEqual(missingForGuard({ blockedApps: [], floatingTimer: true, dndMode: 'priority' }, none).map((m) => m.key), ['overlay', 'notificationPolicy']);
  // Either detection permission is enough.
  assert.deepEqual(missingForGuard(cfg, { ...allPerms, usageAccess: false, accessibility: true }), []);
});

/* ---------- reconcile ---------- */

test('no guarded timer: leave a clean native side alone, clear a dirty one', () => {
  assert.deepEqual(reconcileGuard(null, EMPTY_NATIVE_SESSION, T0), { type: 'none' });
  assert.deepEqual(reconcileGuard(null, { ...EMPTY_NATIVE_SESSION, active: true, id: 'x' }, T0), { type: 'stop-native' });
  assert.deepEqual(reconcileGuard(null, { ...EMPTY_NATIVE_SESSION, endedReason: 'stopped' }, T0), { type: 'stop-native' });
  const plain = createTimer({ kind: 'focus', minutes: 25 }, T0, 'p');
  assert.deepEqual(reconcileGuard(plain, EMPTY_NATIVE_SESSION, T0), { type: 'none' });
  assert.deepEqual(reconcileGuard(plain, { ...EMPTY_NATIVE_SESSION, active: true, id: 'p' }, T0), { type: 'stop-native' });
});

test('a new guarded timer starts the native session; a running one is left alone', () => {
  const t = guarded();
  assert.deepEqual(reconcileGuard(t, EMPTY_NATIVE_SESSION, T0), { type: 'start' });
  assert.deepEqual(reconcileGuard(t, nativeFor(t), T0 + MIN), { type: 'none' });
});

test('after a restart or reboot the native side is started again, with the right remaining time', () => {
  const t = guarded();
  assert.deepEqual(reconcileGuard(t, { ...EMPTY_NATIVE_SESSION }, T0 + 10 * MIN), { type: 'start' });
  assert.deepEqual(reconcileGuard(t, nativeFor(t, { active: false }), T0 + 10 * MIN), { type: 'start' });
  assert.equal(timerToNative(t).plannedMs, 25 * MIN);
});

test('an expired timer is never restarted natively', () => {
  const t = guarded();
  assert.deepEqual(reconcileGuard(t, EMPTY_NATIVE_SESSION, T0 + 26 * MIN), { type: 'none' });
  assert.deepEqual(reconcileGuard(t, nativeFor(t, { active: false, endedReason: 'expired' }), T0 + 26 * MIN), { type: 'none' });
});

test('pause in the app is copied to the native side, never reversed by it', () => {
  const t = guarded();
  const paused = pauseTimer(t, T0 + 5 * MIN);
  // Native still thinks it is running, no command pending: the app wins.
  assert.deepEqual(reconcileGuard(paused, nativeFor(t), T0 + 5 * MIN), { type: 'sync' });
  assert.deepEqual(reconcileGuard(paused, nativeFor(paused), T0 + 6 * MIN), { type: 'none' });
});

test('presses on the floating timer are applied to the app with their own timestamps', () => {
  const t = guarded();
  const n = nativeFor(t, { pausedAt: T0 + 3 * MIN, pendingCommand: 'pause', pendingAt: T0 + 3 * MIN });
  assert.deepEqual(reconcileGuard(t, n, T0 + 9 * MIN), { type: 'apply', command: 'pause', at: T0 + 3 * MIN });
  const stop = nativeFor(t, { active: false, endedReason: 'stopped', endedAt: T0 + 4 * MIN, pendingCommand: 'stop', pendingAt: T0 + 4 * MIN });
  assert.deepEqual(reconcileGuard(t, stop, T0 + 9 * MIN), { type: 'apply', command: 'stop', at: T0 + 4 * MIN });
});

test('a stale command for another session is ignored', () => {
  const t = guarded();
  const stale = { ...EMPTY_NATIVE_SESSION, active: true, id: 'older', pendingCommand: 'stop' as const, pendingAt: T0 };
  assert.deepEqual(reconcileGuard(t, stale, T0 + MIN), { type: 'start' });
});

test('after the app applied a stop and cleared its timer, the native side is cleaned up', () => {
  const ended = { ...EMPTY_NATIVE_SESSION, id: 't1', endedReason: 'stopped' as const, endedAt: T0 + 4 * MIN };
  assert.deepEqual(reconcileGuard(null, ended, T0 + 9 * MIN), { type: 'stop-native' });
});

/* ---------- store integration ---------- */

test('pause and resume can carry the moment the button was pressed', () => {
  const app = makeApp(T0);
  app.actions.startTimer({ kind: 'focus', minutes: 25, guard: cfg });
  app.advance(10 * MIN);
  app.actions.pauseTimer(T0 + 4 * MIN);
  assert.equal(app.state().timer?.pausedAt, T0 + 4 * MIN);
  app.advance(5 * MIN); // now = T0 + 15m
  app.actions.resumeTimer(T0 + 9 * MIN);
  assert.equal(app.state().timer?.pausedAt, null);
  assert.equal(app.state().timer?.pausedTotalMs, 5 * MIN);
  // A timestamp from the future is clamped to now.
  app.actions.pauseTimer(T0 + 999 * MIN);
  assert.equal(app.state().timer?.pausedAt, T0 + 15 * MIN);
});

test('stopping from the floating timer credits time only up to the press', () => {
  const app = makeApp(T0);
  app.actions.startTimer({ kind: 'focus', minutes: 25, guard: cfg });
  app.advance(20 * MIN); // the app was closed for a long while before it noticed
  const res = app.actions.finishTimer(false, T0 + 12 * MIN);
  assert.equal(res?.session?.actualMs, 12 * MIN);
  assert.equal(res?.session?.endedAt, T0 + 12 * MIN);
  assert.equal(app.state().timer, null);
});

test('formatHms pads hours, minutes and seconds', () => {
  assert.equal(formatHms(5_075_000), '01:24:35');
  assert.equal(formatHms(0), '00:00:00');
  assert.equal(formatHms(-5), '00:00:00');
});
