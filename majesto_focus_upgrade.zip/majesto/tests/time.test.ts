import test from 'node:test';
import assert from 'node:assert/strict';
import { addDays, dayKey, diffDays, formatClock, formatMinutes, greeting, lastNDays, startOfDay, weekdayLetter } from '@/core/time';
import { at } from './helpers';

test('dayKey uses the local calendar day', () => {
  assert.equal(dayKey(at(2026, 9, 20, 0, 5)), '2026-09-20');
  assert.equal(dayKey(at(2026, 9, 20, 23, 59)), '2026-09-20');
});

test('addDays crosses month and year boundaries', () => {
  assert.equal(addDays('2026-09-30', 1), '2026-10-01');
  assert.equal(addDays('2026-01-01', -1), '2025-12-31');
  assert.equal(addDays('2028-02-28', 1), '2028-02-29');
});

test('diffDays counts whole days', () => {
  assert.equal(diffDays('2026-09-20', '2026-09-23'), 3);
  assert.equal(diffDays('2026-09-23', '2026-09-20'), -3);
  assert.equal(diffDays('2026-12-31', '2027-01-01'), 1);
});

test('lastNDays is oldest first and ends today', () => {
  assert.deepEqual(lastNDays('2026-09-20', 3), ['2026-09-18', '2026-09-19', '2026-09-20']);
});

test('startOfDay is local midnight', () => {
  assert.equal(startOfDay('2026-09-20'), new Date(2026, 8, 20).getTime());
});

test('weekdayLetter', () => {
  assert.equal(weekdayLetter('2026-09-20'), 'S'); // Sunday
  assert.equal(weekdayLetter('2026-09-21'), 'M');
});

test('formatClock', () => {
  assert.equal(formatClock(25 * 60_000), '25:00');
  assert.equal(formatClock(61_000), '01:01');
  assert.equal(formatClock(3_725_000), '1:02:05');
  assert.equal(formatClock(1), '00:01'); // rounds up so the timer never shows 00:00 early
  assert.equal(formatClock(0), '00:00');
});

test('formatMinutes', () => {
  assert.equal(formatMinutes(0), '0m');
  assert.equal(formatMinutes(45 * 60_000), '45m');
  assert.equal(formatMinutes(85 * 60_000), '1h 25m');
  assert.equal(formatMinutes(120 * 60_000), '2h');
});

test('greeting by hour', () => {
  assert.equal(greeting(at(2026, 9, 20, 8)), 'Good morning');
  assert.equal(greeting(at(2026, 9, 20, 14)), 'Good afternoon');
  assert.equal(greeting(at(2026, 9, 20, 19)), 'Good evening');
  assert.equal(greeting(at(2026, 9, 20, 2)), 'Working late');
});
