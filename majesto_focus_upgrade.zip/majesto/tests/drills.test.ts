import test from 'node:test';
import assert from 'node:assert/strict';
import { createRng } from '@/core/rng';
import {
  SPAN_LIVES, SPAN_MAX, advanceSpan, checkSpan, expectedAnswer, generateDigits, initialSpan, isSpanOver, spanPoints,
} from '@/core/drills/span';
import { generateGrid, scoreSchulte } from '@/core/drills/schulte';
import { generateStroopTrials, scoreStroop, STROOP_TRIALS } from '@/core/drills/stroop';
import { generateNBack, scoreNBack } from '@/core/drills/nback';
import { familiesForLevel, generatePuzzle, scoreSequence } from '@/core/drills/sequence';
import { DRILLS, DRILL_ORDER, isDrillKind } from '@/core/drills';

test('rng is deterministic per seed and stays in range', () => {
  const a = createRng(42);
  const b = createRng(42);
  for (let i = 0; i < 50; i++) assert.equal(a.next(), b.next());
  const r = createRng(7);
  for (let i = 0; i < 500; i++) {
    const n = r.int(3, 6);
    assert.ok(n >= 3 && n <= 6 && Number.isInteger(n));
  }
  assert.deepEqual(createRng(1).shuffle([1, 2, 3, 4, 5]).sort(), [1, 2, 3, 4, 5]);
});

/* ---------- span ---------- */

test('digit sequences have the right length and no back-to-back repeats', () => {
  const rng = createRng(3);
  for (let len = 3; len <= 12; len++) {
    const d = generateDigits(rng, len);
    assert.equal(d.length, len);
    for (let i = 1; i < d.length; i++) assert.notEqual(d[i], d[i - 1]);
  }
});

test('span answers: forward and backward', () => {
  assert.deepEqual(expectedAnswer([1, 2, 3], 'backward'), [3, 2, 1]);
  assert.ok(checkSpan([4, 5, 6], [4, 5, 6], 'forward'));
  assert.ok(!checkSpan([4, 5, 6], [6, 5, 4], 'forward'));
  assert.ok(checkSpan([4, 5, 6], [6, 5, 4], 'backward'));
  assert.ok(!checkSpan([4, 5, 6], [4, 5], 'forward'));
});

test('span progression: grows on success, loses a life on failure, ends at zero lives', () => {
  let s = initialSpan();
  s = advanceSpan(s, true);
  s = advanceSpan(s, true);
  assert.equal(s.length, 5);
  assert.equal(s.best, 4);
  s = advanceSpan(s, false);
  assert.equal(s.lives, SPAN_LIVES - 1);
  assert.equal(s.length, 5);
  assert.equal(isSpanOver(s), false);
  s = advanceSpan(s, false);
  assert.equal(isSpanOver(s), true);
  assert.equal(s.best, 4);
  assert.equal(s.trials, 4);
});

test('span ends when the maximum length is reached', () => {
  let s = initialSpan();
  while (!isSpanOver(s)) s = advanceSpan(s, true);
  assert.equal(s.best, SPAN_MAX);
});

test('span points scale with best length', () => {
  assert.equal(spanPoints(0), 0);
  assert.equal(spanPoints(2), 0);
  assert.equal(spanPoints(6), 500);
  assert.equal(spanPoints(10), 1000);
  assert.equal(spanPoints(12), 1000);
});

/* ---------- schulte ---------- */

test('schulte grid is a permutation of 1..n^2', () => {
  const g = generateGrid(createRng(5), 5);
  assert.deepEqual(g.slice().sort((a, b) => a - b), Array.from({ length: 25 }, (_, i) => i + 1));
});

test('schulte scoring', () => {
  assert.equal(scoreSchulte(5, 25_000, 0).points, 1000); // 1s per cell
  assert.equal(scoreSchulte(5, 65_000, 0).points, 0); // slower than baseline
  const mid = scoreSchulte(5, 45_000, 0);
  assert.equal(mid.points, 500);
  assert.equal(scoreSchulte(5, 25_000, 4).points < 1000, true); // misses cost a second each
  assert.match(mid.summary, /45\.0s on 5x5, no misses/);
  assert.match(scoreSchulte(4, 30_000, 2).summary, /2 misses/);
});

test('schulte suggests a bigger grid after a strong run and a smaller one after a weak run', () => {
  assert.equal(scoreSchulte(4, 17_000, 0).nextSize, 5);
  assert.equal(scoreSchulte(5, 24_000, 0).nextSize, 5);
  assert.equal(scoreSchulte(4, 41_000, 0).nextSize, 3);
  assert.equal(scoreSchulte(3, 30_000, 0).nextSize, 3);
});

/* ---------- stroop ---------- */

test('stroop trials: right count and a mix of congruent and clashing', () => {
  const t = generateStroopTrials(createRng(11));
  assert.equal(t.length, STROOP_TRIALS);
  const congruent = t.filter((x) => x.word === x.ink).length;
  assert.ok(congruent > 0 && congruent < t.length);
});

test('stroop scoring rewards accuracy and speed', () => {
  const fast = Array.from({ length: 10 }, () => ({ correct: true, rtMs: 700 }));
  const slow = Array.from({ length: 10 }, () => ({ correct: true, rtMs: 2200 }));
  const sloppy = Array.from({ length: 10 }, (_, i) => ({ correct: i < 5, rtMs: 700 }));
  assert.equal(scoreStroop(fast).points, 1000);
  assert.equal(scoreStroop(slow).points, 400);
  assert.ok(scoreStroop(sloppy).points < scoreStroop(slow).points);
  assert.equal(scoreStroop([]).points, 0);
  assert.equal(scoreStroop([{ correct: false, rtMs: 500 }]).points, 0);
});

/* ---------- n-back ---------- */

test('n-back sequences mark targets correctly and include some', () => {
  for (const n of [1, 2, 3]) {
    const { stimuli, targets } = generateNBack(createRng(n * 13), n, 40);
    assert.equal(stimuli.length, 40);
    for (let i = 0; i < 40; i++) {
      assert.equal(targets[i], i >= n && stimuli[i] === stimuli[i - n]);
    }
    assert.ok(targets.some(Boolean));
    assert.ok(!targets.slice(0, n).some(Boolean));
  }
});

test('n-back scoring ignores the first n trials', () => {
  const trials = [
    { target: false, responded: true }, // ignored for n=1
    { target: true, responded: true },
    { target: true, responded: false },
    { target: false, responded: true },
    { target: false, responded: false },
  ];
  const s = scoreNBack(1, trials);
  assert.equal(s.hits, 1);
  assert.equal(s.misses, 1);
  assert.equal(s.falseAlarms, 1);
  assert.equal(s.correctRejections, 1);
  assert.equal(s.balanced, 0.5);
  assert.equal(s.points, 0);
});

test('n-back perfect run scores 1000 and levels up, chance-level run levels down', () => {
  const perfect = Array.from({ length: 12 }, (_, i) => ({ target: i % 3 === 0, responded: i % 3 === 0 }));
  const s = scoreNBack(2, perfect);
  assert.equal(s.points, 1000);
  assert.equal(s.nextLevel, 3);
  const random = Array.from({ length: 12 }, (_, i) => ({ target: i % 2 === 0, responded: i % 4 < 2 }));
  assert.equal(scoreNBack(2, random).nextLevel, 1);
});

test('n-back level is capped', () => {
  const perfect = Array.from({ length: 12 }, (_, i) => ({ target: i % 3 === 0, responded: i % 3 === 0 }));
  assert.equal(scoreNBack(4, perfect).nextLevel, 4);
});

/* ---------- sequences ---------- */

test('every generated puzzle is well formed, at every level', () => {
  for (let level = 1; level <= 5; level++) {
    const rng = createRng(level * 101);
    for (let i = 0; i < 300; i++) {
      const p = generatePuzzle(rng, level);
      assert.equal(p.terms.length, 5);
      assert.equal(p.options.length, 4);
      assert.equal(new Set(p.options).size, 4, `duplicate options in ${JSON.stringify(p)}`);
      assert.ok(p.options.includes(p.answer));
      assert.ok(p.terms.every(Number.isInteger) && Number.isInteger(p.answer));
      assert.ok(Math.abs(p.answer) < 100_000);
      assert.ok(p.rule.length > 0);
    }
  }
});

test('puzzle answers follow their stated rule', () => {
  const rng = createRng(99);
  for (let i = 0; i < 500; i++) {
    const p = generatePuzzle(rng, 5);
    const t = p.terms;
    const a = p.answer;
    switch (p.family) {
      case 'arithmetic':
        assert.equal(a - t[4], t[4] - t[3]);
        break;
      case 'geometric':
        assert.equal(a * t[3], t[4] * t[4]);
        break;
      case 'growing':
        assert.equal(a - t[4], t[4] - t[3] + 1);
        break;
      case 'fibonacci':
        assert.equal(a, t[3] + t[4]);
        break;
      case 'alternating': {
        // the last step of the pattern is the opposite of the step before it
        assert.equal(Math.sign(a - t[4]), -Math.sign(t[4] - t[3]));
        break;
      }
      default:
        break;
    }
  }
});

test('higher levels unlock more families', () => {
  const n = (l: number) => familiesForLevel(l).length;
  assert.ok(n(1) < n(2) && n(2) < n(3) && n(3) < n(4));
});

test('sequence scoring', () => {
  assert.equal(scoreSequence(2, 10, 10, 4000).points, 1000);
  assert.equal(scoreSequence(2, 10, 10, 20000).points, 700);
  assert.equal(scoreSequence(2, 0, 10, 4000).points, 0);
  assert.equal(scoreSequence(2, 9, 10, 5000).nextLevel, 3);
  assert.equal(scoreSequence(2, 3, 10, 5000).nextLevel, 1);
  assert.equal(scoreSequence(5, 10, 10, 5000).nextLevel, 5);
});

test('drill catalog is complete', () => {
  assert.equal(DRILL_ORDER.length, 5);
  for (const k of DRILL_ORDER) {
    assert.equal(DRILLS[k].kind, k);
    assert.ok(DRILLS[k].levels.some((l) => l.value === DRILLS[k].defaultLevel));
  }
  assert.ok(isDrillKind('span'));
  assert.ok(!isDrillKind('nope'));
  assert.ok(!isDrillKind(undefined));
});
