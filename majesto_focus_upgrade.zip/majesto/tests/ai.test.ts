import test from 'node:test';
import assert from 'node:assert/strict';
import {
  TutorError, askTutor, buildBody, describeError, normalizeEndpoint, trimHistory, validateRequest,
  type TutorMessage, type TutorRequest,
} from '@/core/ai';

const img = { mediaType: 'image/jpeg' as const, base64: 'AAAA' };
const ask = (text: string, image?: typeof img): TutorRequest => ({ detail: 'brief', messages: [{ role: 'user', text, ...(image ? { image } : {}) }] });

function fakeFetch(status: number, body: unknown, headers: Record<string, string> = {}) {
  const calls: { url: string; init: RequestInit }[] = [];
  const impl = (async (url: string, init: RequestInit) => {
    calls.push({ url, init });
    return {
      ok: status >= 200 && status < 300,
      status,
      headers: { get: (k: string) => headers[k.toLowerCase()] ?? null },
      json: async () => {
        if (body === undefined) throw new Error('not json');
        return body;
      },
    } as unknown as Response;
  }) as unknown as typeof fetch;
  return { impl, calls };
}

const rejects = async (p: Promise<unknown>, code: string) => {
  await assert.rejects(p, (e: unknown) => e instanceof TutorError && e.code === code);
};

test('endpoint normalisation: https everywhere, http only for local development', () => {
  assert.equal(normalizeEndpoint(' https://api.example.com/ '), 'https://api.example.com');
  assert.equal(normalizeEndpoint('https://api.example.com/v1/'), 'https://api.example.com/v1');
  assert.equal(normalizeEndpoint('http://10.0.2.2:8787'), 'http://10.0.2.2:8787');
  assert.equal(normalizeEndpoint('http://example.com'), null);
  assert.equal(normalizeEndpoint('ftp://example.com'), null);
  assert.equal(normalizeEndpoint('example.com'), null);
  assert.equal(normalizeEndpoint(''), null);
  assert.equal(normalizeEndpoint(undefined), null);
});

test('without an endpoint nothing is sent and nothing is invented', async () => {
  const f = fakeFetch(200, { answer: 'x' });
  await rejects(askTutor(ask('2+2?'), { endpoint: '', fetchImpl: f.impl }), 'not-configured');
  await rejects(askTutor(ask('2+2?'), { endpoint: 'http://example.com', fetchImpl: f.impl }), 'not-configured');
  assert.equal(f.calls.length, 0);
});

test('request validation', () => {
  assert.equal(validateRequest(ask('What is a mole?')), null);
  assert.equal(validateRequest(ask('', img)), null);
  assert.equal(validateRequest(ask('   '))?.code, 'invalid-request');
  assert.equal(validateRequest({ detail: 'brief', messages: [] })?.code, 'invalid-request');
  assert.equal(validateRequest({ detail: 'brief', messages: [{ role: 'assistant', text: 'hi' }] })?.code, 'invalid-request');
  assert.equal(validateRequest(ask('x'.repeat(6001)))?.code, 'too-large');
  assert.equal(validateRequest(ask('look', { mediaType: 'image/gif' as never, base64: 'AAAA' }))?.code, 'bad-image');
});

test('a good answer is returned trimmed, and the request carries the conversation', async () => {
  const f = fakeFetch(200, { answer: '  x = 4\nBecause 2x = 8.  ' });
  const res = await askTutor(ask('Solve 2x = 8', img), { endpoint: 'https://api.example.com/', token: 'secret', fetchImpl: f.impl });
  assert.equal(res.answer, 'x = 4\nBecause 2x = 8.');
  assert.equal(f.calls[0].url, 'https://api.example.com/solve');
  const headers = f.calls[0].init.headers as Record<string, string>;
  assert.equal(headers['x-majesto-token'], 'secret');
  const sent = JSON.parse(String(f.calls[0].init.body));
  assert.equal(sent.detail, 'brief');
  assert.equal(sent.messages[0].text, 'Solve 2x = 8');
  assert.equal(sent.messages[0].image.mediaType, 'image/jpeg');
});

test('no token header when no token is configured', async () => {
  const f = fakeFetch(200, { answer: 'ok' });
  await askTutor(ask('hi'), { endpoint: 'https://a.example.com', fetchImpl: f.impl });
  assert.equal((f.calls[0].init.headers as Record<string, string>)['x-majesto-token'], undefined);
});

test('failures map to specific, honest errors', async () => {
  const cfg = (f: ReturnType<typeof fakeFetch>) => ({ endpoint: 'https://a.example.com', fetchImpl: f.impl });
  await rejects(askTutor(ask('q'), cfg(fakeFetch(401, { error: { code: 'unauthorized', message: 'no' } }))), 'unauthorized');
  await rejects(askTutor(ask('q'), cfg(fakeFetch(413, {}))), 'too-large');
  await rejects(askTutor(ask('q'), cfg(fakeFetch(400, { error: { code: 'bad_image', message: 'Cannot read this image.' } }))), 'bad-image');
  await rejects(askTutor(ask('q'), cfg(fakeFetch(400, { error: { code: 'invalid_request', message: 'Question is empty.' } }))), 'invalid-request');
  await rejects(askTutor(ask('q'), cfg(fakeFetch(502, { error: { code: 'upstream', message: 'Upstream failed.' } }))), 'server');
  await rejects(askTutor(ask('q'), cfg(fakeFetch(200, { answer: '   ' }))), 'bad-response');
  await rejects(askTutor(ask('q'), cfg(fakeFetch(200, undefined))), 'bad-response');
  await rejects(askTutor(ask('q'), cfg(fakeFetch(500, undefined))), 'server');
});

test('rate limiting reports how long to wait', async () => {
  const f = fakeFetch(429, { error: { code: 'rate_limited', message: 'slow down' } }, { 'retry-after': '12' });
  try {
    await askTutor(ask('q'), { endpoint: 'https://a.example.com', fetchImpl: f.impl });
    assert.fail('should throw');
  } catch (e) {
    assert.ok(e instanceof TutorError);
    assert.equal(e.code, 'rate-limited');
    assert.equal(e.retryAfterSec, 12);
    assert.match(describeError(e), /12s/);
  }
});

test('network failure and timeout are different errors', async () => {
  const offline = (async () => { throw new TypeError('Network request failed'); }) as unknown as typeof fetch;
  await rejects(askTutor(ask('q'), { endpoint: 'https://a.example.com', fetchImpl: offline }), 'offline');

  const hang = ((_url: string, init: RequestInit) =>
    new Promise((_res, rej) => {
      init.signal?.addEventListener('abort', () => rej(Object.assign(new Error('aborted'), { name: 'AbortError' })));
    })) as unknown as typeof fetch;
  await rejects(askTutor(ask('q'), { endpoint: 'https://a.example.com', fetchImpl: hang, timeoutMs: 20 }), 'timeout');
});

test('long conversations keep the newest turns and do not lose the picture', () => {
  const msgs: TutorMessage[] = [{ role: 'user', text: 'q0', image: img }];
  for (let i = 1; i <= 8; i++) {
    msgs.push({ role: 'assistant', text: `a${i}` }, { role: 'user', text: `q${i}` });
  }
  const t = trimHistory(msgs, 6);
  assert.ok(t.length <= 6);
  assert.equal(t[0].role, 'user');
  assert.equal(t[t.length - 1].text, 'q8');
  assert.equal(t.filter((m) => m.image).length, 1);
  assert.equal(t[0].image?.base64, 'AAAA');
  for (let i = 1; i < t.length; i++) assert.notEqual(t[i].role, t[i - 1].role);

  const body = buildBody({ detail: 'detailed', messages: msgs }) as { messages: unknown[] };
  assert.ok(body.messages.length <= 12);
});

test('describeError never leaks internals', () => {
  assert.equal(describeError(new Error('ECONNRESET at 10.0.0.1')), 'Something went wrong. Please try again.');
});
