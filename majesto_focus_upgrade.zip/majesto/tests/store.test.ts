import test from 'node:test';
import assert from 'node:assert/strict';
import { createStore } from '@/store/store';
import { createActions } from '@/store/actions';
import { attachPersistence, createMemoryStorage } from '@/store/persistence';
import { SCHEMA_VERSION, STORAGE_KEY, createInitialState, migrate, toPersisted } from '@/store/state';
import { computeStreak } from '@/core/streak';
import { MINUTE, DAY } from '@/core/time';
import { levelFromXp } from '@/core/xp';
import { at, makeApp } from './helpers';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/* ---------- state / migration ---------- */

test('a fresh install has a starter deck of new cards', () => {
  const app = makeApp();
  assert.equal(app.state().decks.length, 1);
  assert.ok(app.state().cards.length >= 5);
  assert.ok(app.state().cards.every((c) => c.srs.phase === 'new'));
  assert.equal(app.state().profile.onboarded, false);
});

test('migrate: garbage becomes a fresh state', () => {
  const ids = (() => { let n = 0; return () => `x${++n}`; })();
  for (const raw of [null, undefined, 42, 'text', [], true]) {
    const s = migrate(raw, 1000, ids);
    assert.equal(s.version, SCHEMA_VERSION);
    assert.ok(s.decks.length > 0);
  }
});

test('migrate: partial data is filled with defaults and orphan cards are dropped', () => {
  const ids = () => 'x';
  const s = migrate(
    {
      xp: 250,
      settings: { focusMin: 40 },
      decks: [{ id: 'd1', name: 'A', color: '#fff', createdAt: 1 }],
      cards: [
        { id: 'c1', deckId: 'd1', front: 'f', back: 'b', createdAt: 5 },
        { id: 'c2', deckId: 'gone', front: 'f', back: 'b', createdAt: 5 },
      ],
    },
    2000,
    ids,
  );
  assert.equal(s.xp, 250);
  assert.equal(s.settings.focusMin, 40);
  assert.equal(s.settings.breakMin, 5);
  assert.equal(s.cards.length, 1);
  assert.equal(s.cards[0].srs.phase, 'new');
  assert.deepEqual(s.tasks, []);
  assert.deepEqual(s.drills, { results: [], stats: {}, levels: {} });
});

test('migrate does not re-seed the starter deck for an existing user with no decks', () => {
  const s = migrate({ version: 1, xp: 10, decks: [], cards: [] }, 1, () => 'x');
  assert.equal(s.decks.length, 0);
});

/* ---------- persistence ---------- */

test('hydrate loads saved data', async () => {
  const seed = makeApp();
  seed.actions.addTask('Read chapter 3');
  const storage = createMemoryStorage({ [STORAGE_KEY]: JSON.stringify(toPersisted(seed.state())) });

  const fresh = createStore(createInitialState(0, () => 'y'));
  const actions = createActions(fresh, { now: () => 5, id: () => 'z' });
  await actions.hydrate(storage);
  assert.equal(fresh.get().hydrated, true);
  assert.equal(fresh.get().tasks[0].title, 'Read chapter 3');
});

test('hydrate survives corrupted storage', async () => {
  const storage = createMemoryStorage({ [STORAGE_KEY]: '{not json' });
  const fresh = createStore(createInitialState(0, () => 'y'));
  const actions = createActions(fresh, { now: () => 5, id: () => 'z' });
  await actions.hydrate(storage);
  assert.equal(fresh.get().hydrated, true);
  assert.ok(fresh.get().decks.length > 0);
});

test('persistence saves after changes, debounced, and ignores toast-only changes', async () => {
  const app = makeApp();
  const storage = createMemoryStorage();
  const handle = attachPersistence(app.store, storage, { debounceMs: 20 });

  app.actions.addTask('One');
  app.actions.addTask('Two');
  assert.equal(storage.data[STORAGE_KEY], undefined); // debounced
  await sleep(60);
  const saved = JSON.parse(storage.data[STORAGE_KEY]);
  assert.equal(saved.tasks.length, 2);
  assert.equal('toasts' in saved, false);
  assert.equal('hydrated' in saved, false);

  const before = storage.data[STORAGE_KEY];
  delete storage.data[STORAGE_KEY];
  app.store.set((s) => ({ ...s, toasts: [{ id: 't', kind: 'info', title: 'x', body: 'y' }] }));
  await sleep(60);
  assert.equal(storage.data[STORAGE_KEY], undefined, 'toast change should not write');

  app.actions.addTask('Three');
  await handle.flush();
  assert.equal(JSON.parse(storage.data[STORAGE_KEY]).tasks.length, 3);
  assert.notEqual(storage.data[STORAGE_KEY], before);
  handle.stop();
});

test('persistence does not write before hydration', async () => {
  const s = createStore(createInitialState(0, () => 'a'));
  const storage = createMemoryStorage();
  const handle = attachPersistence(s, storage, { debounceMs: 5 });
  s.set((x) => ({ ...x, xp: 5 }));
  await handle.flush();
  assert.equal(storage.data[STORAGE_KEY], undefined);
  handle.stop();
});

test('a round trip through storage preserves everything', async () => {
  const app = makeApp();
  app.actions.addTask('Task');
  app.actions.addDeck('Spanish');
  const storage = createMemoryStorage();
  const h = attachPersistence(app.store, storage, { debounceMs: 1 });
  await h.flush();
  const again = createStore(createInitialState(0, () => 'q'));
  await createActions(again, { now: () => 1, id: () => 'w' }).hydrate(storage);
  assert.deepEqual(toPersisted(again.get()), toPersisted(app.state()));
  h.stop();
});

/* ---------- tasks ---------- */

test('tasks: add, complete, uncomplete, delete', () => {
  const app = makeApp();
  assert.equal(app.actions.addTask('   '), null);
  const id = app.actions.addTask('  Write intro  ')!;
  assert.equal(app.state().tasks[0].title, 'Write intro');
  app.actions.toggleTask(id);
  assert.ok(app.state().tasks[0].doneAt);
  assert.equal(Object.values(app.state().activity)[0].tasksDone, 1);
  app.actions.toggleTask(id);
  assert.equal(app.state().tasks[0].doneAt, null);
  assert.equal(Object.values(app.state().activity)[0].tasksDone, 0);
  app.actions.deleteTask(id);
  assert.equal(app.state().tasks.length, 0);
});

test('toggling a task on and off cannot farm xp', () => {
  const app = makeApp();
  const id = app.actions.addTask('x')!;
  const before = app.state().xp;
  for (let i = 0; i < 6; i++) app.actions.toggleTask(id);
  assert.equal(app.state().xp, before);
});

/* ---------- focus flow ---------- */

test('a full focus session: credit, xp, activity, task time', () => {
  const app = makeApp();
  const taskId = app.actions.addTask('Thesis')!;
  app.actions.startTimer({ kind: 'focus', minutes: 25, taskId, label: '' });
  app.advance(10 * MINUTE);
  app.actions.pauseTimer();
  app.advance(60 * MINUTE); // paused time does not count
  app.actions.resumeTimer();
  app.actions.addDistraction();
  app.advance(15 * MINUTE);
  const res = app.actions.finishTimer(true)!;

  assert.equal(res.kind, 'focus');
  assert.equal(res.session?.actualMs, 25 * MINUTE);
  assert.equal(res.session?.completed, true);
  assert.equal(res.xp, 58); // 50 + 10 bonus - 2 for one distraction
  assert.equal(app.state().timer, null);
  assert.equal(app.state().sessions.length, 1);
  assert.equal(app.state().tasks[0].focusMs, 25 * MINUTE);
  const day = Object.values(app.state().activity)[0];
  assert.equal(day.focusMs, 25 * MINUTE);
  assert.equal(day.sessions, 1);
  assert.ok(app.state().xp >= 58);
});

test('only one timer can run at a time', () => {
  const app = makeApp();
  app.actions.startTimer({ kind: 'focus', minutes: 25 });
  const first = app.state().timer;
  app.actions.startTimer({ kind: 'focus', minutes: 50 });
  assert.equal(app.state().timer, first);
});

test('ending early credits elapsed time; a tiny run and a discard credit nothing', () => {
  const app = makeApp();
  app.actions.startTimer({ kind: 'focus', minutes: 25 });
  app.advance(12 * MINUTE);
  const early = app.actions.finishTimer(false)!;
  assert.equal(early.session?.actualMs, 12 * MINUTE);
  assert.equal(early.session?.completed, false);

  app.actions.startTimer({ kind: 'focus', minutes: 25 });
  app.advance(20_000);
  assert.equal(app.actions.finishTimer(false)!.session, null);

  app.actions.startTimer({ kind: 'focus', minutes: 25 });
  app.advance(20 * MINUTE);
  app.actions.discardTimer();
  assert.equal(app.state().timer, null);
  assert.equal(app.state().sessions.length, 1);
});

test('breaks earn nothing and are not logged', () => {
  const app = makeApp();
  app.actions.startTimer({ kind: 'break', minutes: 5 });
  app.advance(5 * MINUTE);
  const res = app.actions.finishTimer(true)!;
  assert.equal(res.kind, 'break');
  assert.equal(res.xp, 0);
  assert.equal(app.state().sessions.length, 0);
  assert.equal(app.state().xp, 0);
});

test('an interrupted timer survives a reload and completes with capped time', async () => {
  const app = makeApp();
  app.actions.startTimer({ kind: 'focus', minutes: 25 });
  const storage = createMemoryStorage();
  const h = attachPersistence(app.store, storage, { debounceMs: 1 });
  await h.flush();

  const later = makeApp(app.now() + 5 * 60 * MINUTE);
  await later.actions.hydrate(storage);
  assert.ok(later.state().timer);
  const res = later.actions.finishTimer(true)!;
  assert.equal(res.session?.actualMs, 25 * MINUTE);
  h.stop();
});

test('deleting the task attached to a running timer detaches it', () => {
  const app = makeApp();
  const id = app.actions.addTask('x')!;
  app.actions.startTimer({ kind: 'focus', minutes: 25, taskId: id });
  app.actions.deleteTask(id);
  assert.equal(app.state().timer?.taskId, null);
});

/* ---------- recall ---------- */

test('decks and cards: create, edit, delete', () => {
  const app = makeApp();
  assert.equal(app.actions.addDeck('  '), null);
  const deckId = app.actions.addDeck(' Biology ')!;
  assert.equal(app.state().decks.at(-1)?.name, 'Biology');
  assert.equal(app.actions.addCard(deckId, 'Mitochondria', 'Powerhouse'), true);
  assert.equal(app.actions.addCard(deckId, '', 'x'), false);
  assert.equal(app.actions.addCard('missing', 'a', 'b'), false);
  const card = app.state().cards.find((c) => c.deckId === deckId)!;
  app.actions.updateCard(card.id, 'Mitochondria?', 'Makes ATP');
  assert.equal(app.state().cards.find((c) => c.id === card.id)?.back, 'Makes ATP');
  app.actions.updateCard(card.id, '', 'x'); // ignored
  assert.equal(app.state().cards.find((c) => c.id === card.id)?.front, 'Mitochondria?');
  app.actions.deleteCard(card.id);
  assert.equal(app.state().cards.some((c) => c.id === card.id), false);
});

test('addCards imports many at once and keeps their order', () => {
  const app = makeApp();
  const deckId = app.actions.addDeck('Bulk')!;
  const n = app.actions.addCards(deckId, [
    { front: 'a', back: '1' },
    { front: 'b', back: '2' },
    { front: ' ', back: '3' },
  ]);
  assert.equal(n, 2);
  const cards = app.state().cards.filter((c) => c.deckId === deckId);
  assert.deepEqual(cards.map((c) => c.front), ['a', 'b']);
  assert.ok(cards[0].createdAt < cards[1].createdAt);
});

test('deleting a deck removes its cards only', () => {
  const app = makeApp();
  const before = app.state().cards.length;
  const deckId = app.actions.addDeck('Temp')!;
  app.actions.addCard(deckId, 'q', 'a');
  app.actions.deleteDeck(deckId);
  assert.equal(app.state().cards.length, before);
  assert.equal(app.state().decks.some((d) => d.id === deckId), false);
});

test('grading a card schedules it, awards xp and updates activity', () => {
  const app = makeApp();
  const card = app.state().cards[0];
  const res = app.actions.gradeCard(card.id, 'good')!;
  assert.equal(res.xp, 2);
  assert.equal(res.card.srs.phase, 'learning');
  assert.equal(app.state().cards[0].srs.phase, 'learning');
  const day = Object.values(app.state().activity)[0];
  assert.equal(day.reviews, 1);
  assert.equal(day.newCards, 1);

  app.actions.gradeCard(card.id, 'good'); // graduates; no longer a new card
  const day2 = Object.values(app.state().activity)[0];
  assert.equal(day2.reviews, 2);
  assert.equal(day2.newCards, 1);
  assert.equal(app.state().cards[0].srs.phase, 'review');
  assert.equal(app.actions.gradeCard('missing', 'good'), null);
});

/* ---------- drills ---------- */

test('drill results, personal bests and levels', () => {
  const app = makeApp();
  const first = app.actions.recordDrill({ kind: 'stroop', points: 600, summary: 's', accuracy: 0.9, durationMs: 1000, level: 1 })!;
  assert.equal(first.isPersonalBest, false); // the first score is not a "personal best" bonus
  assert.equal(first.result.xp, 10 + 18);
  assert.equal(app.state().drills.stats.stroop?.best, 600);

  const better = app.actions.recordDrill({ kind: 'stroop', points: 800, summary: 's', accuracy: 0.9, durationMs: 1000, level: 1 })!;
  assert.equal(better.isPersonalBest, true);
  assert.equal(better.previousBest, 600);
  assert.equal(better.result.xp, 10 + 24 + 10);

  const worse = app.actions.recordDrill({ kind: 'stroop', points: 300, summary: 's', accuracy: 0.5, durationMs: 1000, level: 1, nextLevel: 1 })!;
  assert.equal(worse.isPersonalBest, false);
  const st = app.state().drills.stats.stroop!;
  assert.equal(st.best, 800);
  assert.equal(st.plays, 3);

  app.actions.recordDrill({ kind: 'nback', points: 500, summary: 's', accuracy: null, durationMs: 1, level: 2, nextLevel: 3 });
  assert.equal(app.state().drills.levels.nback, 3);
  assert.equal(app.state().drills.results.length, 4);
  assert.equal(Object.values(app.state().activity)[0].drills, 4);
});

test('drill history is capped', () => {
  const app = makeApp();
  for (let i = 0; i < 230; i++) app.actions.recordDrill({ kind: 'span', points: 100, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  assert.equal(app.state().drills.results.length, 200);
  assert.equal(app.state().drills.stats.span?.plays, 230);
});

/* ---------- achievements and levels ---------- */

test('achievements unlock once, give xp, and raise a toast', () => {
  const app = makeApp();
  app.actions.recordDrill({ kind: 'span', points: 400, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  const unlocked = Object.keys(app.state().achievements);
  assert.ok(unlocked.includes('first_drill'));
  assert.ok(app.state().toasts.some((t) => t.kind === 'achievement' && t.title === 'Warm-up'));
  const xpAfterFirst = app.state().xp;
  assert.ok(xpAfterFirst >= 10 + 12 + 25);

  const toastCount = app.state().toasts.length;
  app.actions.recordDrill({ kind: 'span', points: 400, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  assert.equal(app.state().toasts.filter((t) => t.title === 'Warm-up').length, 1);
  assert.ok(app.state().toasts.length >= toastCount);
});

test('level-ups raise a toast', () => {
  const app = makeApp();
  app.store.set((s) => ({ ...s, xp: 95 }));
  app.actions.recordDrill({ kind: 'span', points: 1000, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  assert.ok(levelFromXp(app.state().xp) >= 2);
  assert.ok(app.state().toasts.some((t) => t.kind === 'level'));
  app.actions.dismissToast(app.state().toasts[0].id);
});

test('toasts are capped', () => {
  const app = makeApp();
  app.store.set((s) => ({
    ...s,
    toasts: Array.from({ length: 9 }, (_, i) => ({ id: `t${i}`, kind: 'info' as const, title: 't', body: 'b' })),
  }));
  app.actions.addTask('poke');
  assert.equal(app.state().toasts.length, 5);
});

test('streak achievement follows real daily activity', () => {
  const app = makeApp(at(2026, 9, 18, 9));
  for (let d = 0; d < 3; d++) {
    app.actions.recordDrill({ kind: 'span', points: 100, summary: 's', accuracy: null, durationMs: 1, level: 1 });
    app.advance(DAY);
  }
  assert.ok(app.state().achievements.streak_3);
  assert.equal(computeStreak(app.state().activity, '2026-09-20').current, 3);
});

/* ---------- settings / reset / export ---------- */

test('onboarding and settings', () => {
  const app = makeApp();
  app.actions.completeOnboarding('  Ada ', 90);
  assert.equal(app.state().profile.name, 'Ada');
  assert.equal(app.state().profile.onboarded, true);
  assert.equal(app.state().settings.dailyFocusGoalMin, 90);
  app.actions.updateSettings({ haptics: false, focusMin: 50 });
  assert.equal(app.state().settings.haptics, false);
  assert.equal(app.state().settings.focusMin, 50);
  assert.equal(app.state().settings.breakMin, 5);
});

test('export produces valid JSON that migrates back to the same data', () => {
  const app = makeApp();
  app.actions.addTask('t');
  const json = app.actions.exportJson();
  const back = migrate(JSON.parse(json), 1, () => 'x');
  assert.deepEqual(back, toPersisted(app.state()));
});

test('reset returns to a fresh, un-onboarded state and keeps the app running', () => {
  const app = makeApp();
  app.actions.completeOnboarding('Ada', 60);
  app.actions.addTask('t');
  app.actions.recordDrill({ kind: 'span', points: 500, summary: 's', accuracy: null, durationMs: 1, level: 1 });
  app.actions.resetAll();
  const s = app.state();
  assert.equal(s.hydrated, true);
  assert.equal(s.profile.onboarded, false);
  assert.equal(s.tasks.length, 0);
  assert.equal(s.xp, 0);
  assert.deepEqual(s.achievements, {});
  assert.ok(s.decks.length > 0);
});

test('pushToast queues an info toast and respects the cap', () => {
  const app = makeApp();
  app.actions.pushToast('Hello', 'World');
  assert.deepEqual(app.state().toasts.map((t) => [t.kind, t.title, t.body]), [['info', 'Hello', 'World']]);
  for (let i = 0; i < 8; i++) app.actions.pushToast(`t${i}`, 'b');
  assert.equal(app.state().toasts.length, 5);
  assert.equal(app.state().toasts.at(-1)?.title, 't7');
});
