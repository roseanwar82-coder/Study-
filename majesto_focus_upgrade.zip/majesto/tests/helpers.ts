import { createStore } from '@/store/store';
import { createActions } from '@/store/actions';
import { createInitialState } from '@/store/state';
import type { AppState } from '@/core/types';

/** A store with a controllable clock and predictable ids. */
export function makeApp(startMs = new Date(2026, 8, 20, 9, 0, 0).getTime()) {
  let clock = startMs;
  let n = 0;
  const now = () => clock;
  const id = (p = 'id') => `${p}_${++n}`;
  const store = createStore<AppState>({ ...createInitialState(clock, id), hydrated: true });
  const actions = createActions(store, { now, id });
  return {
    store,
    actions,
    state: () => store.get(),
    advance: (ms: number) => {
      clock += ms;
    },
    setTime: (ms: number) => {
      clock = ms;
    },
    now,
    id,
  };
}

export const at = (y: number, m: number, d: number, h = 12, min = 0) => new Date(y, m - 1, d, h, min).getTime();
