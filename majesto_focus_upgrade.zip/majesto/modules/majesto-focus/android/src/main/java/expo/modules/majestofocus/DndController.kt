package expo.modules.majestofocus

import android.app.NotificationManager
import android.content.Context

/**
 * Do Not Disturb for the length of a focus session. This is the least invasive way Android offers to quiet
 * notifications: it needs "Do Not Disturb access" (granted in Settings) and never reads a notification.
 * The filter that was active before the session is saved on disk so it is restored even if the app is killed.
 */
object DndController {
  private const val PREFS = "majesto_focus_dnd"
  private const val KEY_PREVIOUS = "previousFilter"

  /** Returns true when the filter is now (at least as strict as) the requested mode. */
  fun apply(ctx: Context, mode: String): Boolean {
    if (mode != "priority" && mode != "alarms") return false
    if (!Perms.notificationPolicy(ctx)) return false
    return try {
      val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
      val current = nm.currentInterruptionFilter
      val target = if (mode == "alarms") NotificationManager.INTERRUPTION_FILTER_ALARMS else NotificationManager.INTERRUPTION_FILTER_PRIORITY
      // Never weaken what the person already had on.
      val canRaise = current == NotificationManager.INTERRUPTION_FILTER_ALL ||
        (target == NotificationManager.INTERRUPTION_FILTER_ALARMS && current == NotificationManager.INTERRUPTION_FILTER_PRIORITY)
      if (canRaise) {
        if (!prefs.contains(KEY_PREVIOUS)) prefs.edit().putInt(KEY_PREVIOUS, current).apply()
        nm.setInterruptionFilter(target)
      }
      true
    } catch (ignored: Throwable) {
      false
    }
  }

  /** Puts the filter back to what it was before the session. Safe to call any number of times. */
  fun restore(ctx: Context) {
    try {
      val prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
      if (!prefs.contains(KEY_PREVIOUS)) return
      val previous = prefs.getInt(KEY_PREVIOUS, NotificationManager.INTERRUPTION_FILTER_ALL)
      if (Perms.notificationPolicy(ctx)) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val back = if (previous == NotificationManager.INTERRUPTION_FILTER_UNKNOWN) NotificationManager.INTERRUPTION_FILTER_ALL else previous
        nm.setInterruptionFilter(back)
      }
      prefs.edit().remove(KEY_PREVIOUS).apply()
    } catch (ignored: Throwable) {
    }
  }
}
