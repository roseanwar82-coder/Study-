package expo.modules.majestofocus

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Optional, faster way to notice which app came to the front. It is only a messenger: it forwards the package
 * name from window-change events to the running focus service. It cannot read the screen (see the XML config),
 * never stores anything and does nothing when no focus session is running.
 */
class FocusAccessibilityService : AccessibilityService() {

  companion object {
    @Volatile var connected: Boolean = false
      private set
    @Volatile private var instance: FocusAccessibilityService? = null

    /** Sends the person to the home screen. Used only as a fallback when the block screen cannot open. */
    fun goHome(): Boolean {
      val s = instance ?: return false
      return try { s.performGlobalAction(GLOBAL_ACTION_HOME) } catch (ignored: Throwable) { false }
    }
  }

  override fun onServiceConnected() {
    super.onServiceConnected()
    instance = this
    connected = true
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
    val pkg = event.packageName?.toString() ?: return
    FocusService.instance?.onForegroundPackage(pkg)
  }

  override fun onInterrupt() {}

  override fun onUnbind(intent: android.content.Intent?): Boolean {
    connected = false
    instance = null
    return super.onUnbind(intent)
  }

  override fun onDestroy() {
    connected = false
    instance = null
    super.onDestroy()
  }
}
