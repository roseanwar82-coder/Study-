package expo.modules.majestofocus

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream

/** Apps that have a launcher icon, which is all the package visibility our manifest asks for. */
object AppLister {
  private const val ICON_PX = 96

  fun list(ctx: Context): List<Map<String, Any?>> {
    val pm = ctx.packageManager
    val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val resolved = if (Build.VERSION.SDK_INT >= 33) {
      pm.queryIntentActivities(launcher, PackageManager.ResolveInfoFlags.of(0L))
    } else {
      @Suppress("DEPRECATION")
      pm.queryIntentActivities(launcher, 0)
    }
    val blockedForever = Protected.packages(ctx)
    val seen = HashSet<String>()
    val out = ArrayList<Map<String, Any?>>()
    for (ri in resolved) {
      val pkg = ri.activityInfo?.packageName ?: continue
      if (pkg in blockedForever || !seen.add(pkg)) continue
      val label = try { ri.loadLabel(pm).toString() } catch (ignored: Throwable) { pkg }
      val icon = try { iconBase64(ri.loadIcon(pm)) } catch (ignored: Throwable) { null }
      out.add(mapOf("packageName" to pkg, "label" to label, "icon" to icon))
    }
    out.sortBy { (it["label"] as String).lowercase() }
    return out
  }

  private fun iconBase64(d: Drawable): String {
    val bmp = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    d.setBounds(0, 0, ICON_PX, ICON_PX)
    d.draw(canvas)
    val bytes = ByteArrayOutputStream()
    bmp.compress(Bitmap.CompressFormat.PNG, 100, bytes)
    bmp.recycle()
    return Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
  }
}
