package expo.modules.majestofocus

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.Base64
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.records.Field
import expo.modules.kotlin.records.Record
import java.io.File

/** The timer, in the same shape as src/core/guard.ts (NativeTimer). */
class NativeTimer : Record {
  @Field var id: String = ""
  @Field var startedAt: Double = 0.0
  @Field var plannedMs: Double = 0.0
  @Field var pausedAt: Double? = null
  @Field var pausedTotalMs: Double = 0.0
}

/** What the guard should do for the session (GuardOptions in src/core/guard.ts). */
class GuardOptions : Record {
  @Field var blockedPackages: List<String> = emptyList()
  @Field var floatingTimer: Boolean = false
  @Field var dndMode: String = "off"
}

class MajestoFocusModule : Module() {
  private val androidContext: Context
    get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()

  override fun definition() = ModuleDefinition {
    Name("MajestoFocus")

    Events("onCommand", "onBlocked", "onSessionEnded", "onScreenshot", "onSharedImage")

    OnCreate {
      FocusEvents.emitter = { name, body -> sendEvent(name, body) }
      FocusEvents.minimizeApp = { appContext.currentActivity?.moveTaskToBack(true) }
    }

    OnDestroy {
      FocusEvents.emitter = null
      FocusEvents.minimizeApp = null
    }

    OnNewIntent { intent -> handleShareIntent(intent) }

    Function("isSupported") { true }

    /* ----- permissions ----- */

    Function("getPermissions") {
      val c = androidContext
      mapOf(
        "overlay" to Perms.overlay(c),
        "usageAccess" to Perms.usageAccess(c),
        "accessibility" to Perms.accessibility(c),
        "notificationPolicy" to Perms.notificationPolicy(c),
        "notifications" to Perms.notifications(c),
      )
    }

    /** Opens the Android Settings screen where the person grants one permission. Returns false if it cannot be opened. */
    Function("openSettings") { kind: String ->
      val c = androidContext
      val intent = Perms.settingsIntent(c, kind)
      if (intent == null) {
        false
      } else {
        try {
          c.startActivity(intent)
          true
        } catch (ignored: Throwable) {
          false
        }
      }
    }

    AsyncFunction("listApps") {
      AppLister.list(androidContext)
    }

    /* ----- session ----- */

    /**
     * Starts the native side of a focus session, or refreshes it if the same session is already running.
     * Returns what will actually be active, based on the permissions granted right now.
     */
    Function("startSession") { timer: NativeTimer, options: GuardOptions ->
      val c = androidContext
      val store = SessionStore(c)
      val cur = store.read()
      val pausedAt = timer.pausedAt?.toLong() ?: -1L
      val blocked = options.blockedPackages.toSet()
      if (cur.active && cur.id == timer.id) {
        store.update(timer.startedAt.toLong(), timer.plannedMs.toLong(), pausedAt, timer.pausedTotalMs.toLong(), blocked, options.floatingTimer, options.dndMode)
      } else {
        store.begin(timer.id, timer.startedAt.toLong(), timer.plannedMs.toLong(), pausedAt, timer.pausedTotalMs.toLong(), blocked, options.floatingTimer, options.dndMode)
      }
      val started = FocusService.start(c)
      val canDetect = Perms.usageAccess(c) || Perms.accessibility(c)
      mapOf(
        "serviceStarted" to started,
        "floatingTimer" to (options.floatingTimer && Perms.overlay(c)),
        "blocking" to (blocked.isNotEmpty() && Perms.overlay(c) && canDetect),
        "dnd" to (options.dndMode != "off" && Perms.notificationPolicy(c)),
      )
    }

    /** The app paused or resumed the timer: copy it over. */
    Function("syncTimer") { timer: NativeTimer ->
      val c = androidContext
      val store = SessionStore(c)
      val cur = store.read()
      if (cur.active && cur.id == timer.id) {
        store.update(
          timer.startedAt.toLong(), timer.plannedMs.toLong(), timer.pausedAt?.toLong() ?: -1L, timer.pausedTotalMs.toLong(),
          cur.blocked, cur.floating, cur.dnd,
        )
        FocusService.instance?.postRefresh()
      }
    }

    /** The app has applied the press that was waiting. */
    Function("ackCommand") {
      SessionStore(androidContext).clearPending()
    }

    /** Ends the native side completely: floating timer, blocker, Do Not Disturb, notification. */
    Function("stopGuard") {
      val c = androidContext
      SessionStore(c).clear()
      FocusService.instance?.postShutdown()
      DndController.restore(c)
    }

    Function("getSessionState") {
      val s = SessionStore(androidContext).read()
      mapOf(
        "active" to s.active,
        "id" to (if (s.id.isEmpty()) null else s.id),
        "startedAt" to s.startedAt.toDouble(),
        "plannedMs" to s.plannedMs.toDouble(),
        "pausedAt" to (if (s.paused) s.pausedAt.toDouble() else null),
        "pausedTotalMs" to s.pausedTotalMs.toDouble(),
        "endedReason" to (if (s.endedReason.isEmpty()) null else s.endedReason),
        "endedAt" to (if (s.endedReason.isEmpty()) null else s.endedAt.toDouble()),
        "pendingCommand" to (if (s.pendingCommand.isEmpty()) null else s.pendingCommand),
        "pendingAt" to (if (s.pendingCommand.isEmpty()) null else s.pendingAt.toDouble()),
        "blockedAttempts" to s.attempts,
      )
    }

    /* ----- AI help: pictures ----- */

    /** Takes one screenshot after Android's own consent dialog. With minimize, Majesto steps aside first so the study app is what gets captured. */
    Function("captureScreen") { minimize: Boolean ->
      ScreenCapture.begin(androidContext, minimize)
    }

    Function("minimizeApp") {
      appContext.currentActivity?.moveTaskToBack(true)
    }

    /** Looks at the intent that opened Majesto. If another app shared a picture, it is copied in the background. */
    Function("checkShareIntent") {
      handleShareIntent(appContext.currentActivity?.intent)
    }

    Function("hasPendingImage") {
      SessionStore(androidContext).pendingImage() != null
    }

    Function("takePendingImage") {
      SessionStore(androidContext).takePendingImage()
    }

    AsyncFunction("readImageBase64") { path: String ->
      val c = androidContext
      if (!ImageFiles.isOurs(c, path)) throw IllegalArgumentException("Not an image created by Majesto.")
      Base64.encodeToString(File(path).readBytes(), Base64.NO_WRAP)
    }

    Function("deleteImage") { path: String ->
      val c = androidContext
      if (ImageFiles.isOurs(c, path)) File(path).delete() else false
    }
  }

  /** A picture shared into Majesto from another app (for example a screenshot or a video frame). */
  private fun handleShareIntent(intent: Intent?) {
    if (intent == null || intent.action != Intent.ACTION_SEND) return
    val type = intent.type ?: return
    if (!type.startsWith("image/")) return
    val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
      intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
    } else {
      @Suppress("DEPRECATION")
      intent.getParcelableExtra(Intent.EXTRA_STREAM)
    }
    // Handle each share once, even if the activity is recreated with the same intent.
    intent.action = Intent.ACTION_MAIN
    intent.removeExtra(Intent.EXTRA_STREAM)
    if (uri == null) return
    val c = androidContext
    Thread {
      try {
        val bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return@Thread
        val file = ImageFiles.saveScaledJpeg(c, bmp, "shared")
        bmp.recycle()
        SessionStore(c).setPendingImage(file.absolutePath)
        FocusEvents.emit("onSharedImage", mapOf("path" to file.absolutePath))
      } catch (ignored: Throwable) {
        FocusEvents.emit("onSharedImage", mapOf("error" to "unreadable"))
      }
    }.start()
  }
}
