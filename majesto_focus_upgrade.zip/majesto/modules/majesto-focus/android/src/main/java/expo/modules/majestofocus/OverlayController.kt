package expo.modules.majestofocus

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * The floating timer: a small draggable pill that expands into a compact control panel.
 * It only exists while a focus session runs and Android's "Display over other apps" permission is granted.
 * Everything here is built in code so the module needs no layout files.
 */
class OverlayController(private val ctx: Context, private val actions: Actions) {

  interface Actions {
    fun pause()
    fun resume()
    fun stop()
    fun openAssist()
    fun captureScreen()
  }

  private enum class Mode { BUBBLE, PANEL, AI, CONFIRM_STOP }

  private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
  private val dp = ctx.resources.displayMetrics.density
  private val store = SessionStore(ctx)
  private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

  private var root: FrameLayout? = null
  private var params: WindowManager.LayoutParams? = null
  private var timeView: TextView? = null
  private var mode = Mode.BUBBLE
  private var builtKey = ""
  private var hidden = false
  private var bubbleX = 0
  private var bubbleY = 0

  val isShown: Boolean get() = root != null

  private fun px(v: Float): Int = (v * dp).toInt()

  fun show() {
    if (root != null || !Perms.overlay(ctx)) return
    val type = if (Build.VERSION.SDK_INT >= 26) {
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
      @Suppress("DEPRECATION")
      WindowManager.LayoutParams.TYPE_PHONE
    }
    val lp = WindowManager.LayoutParams(
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.WRAP_CONTENT,
      type,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
      PixelFormat.TRANSLUCENT,
    )
    lp.gravity = Gravity.TOP or Gravity.START
    val sw = ctx.resources.displayMetrics.widthPixels
    val sh = ctx.resources.displayMetrics.heightPixels
    lp.x = if (store.overlayX() >= 0) clampX(store.overlayX(), px(120f)) else sw - px(140f)
    lp.y = if (store.overlayY() >= 0) clampY(store.overlayY(), px(40f)) else (sh * 0.2f).toInt()

    val container = FrameLayout(ctx)
    container.setOnTouchListener(touch)
    try {
      wm.addView(container, lp)
    } catch (ignored: Throwable) {
      return
    }
    root = container
    params = lp
    mode = Mode.BUBBLE
    builtKey = ""
    container.visibility = if (hidden) View.GONE else View.VISIBLE
  }

  fun remove() {
    val r = root ?: return
    try {
      wm.removeView(r)
    } catch (ignored: Throwable) {
    }
    root = null
    params = null
    timeView = null
    builtKey = ""
  }

  /** Hides the timer without losing it, for example while a screenshot is taken. */
  fun setHidden(value: Boolean) {
    // Callers may be on the JS thread; views must only be touched on the main thread.
    Handler(Looper.getMainLooper()).post {
      hidden = value
      root?.visibility = if (value) View.GONE else View.VISIBLE
    }
  }

  /** Called about twice a second. Cheap when nothing changed. */
  fun render(s: SessionStore.Snapshot, now: Long) {
    if (root == null) return
    val key = "$mode|${s.paused}|${s.attempts}"
    if (key != builtKey) rebuild(s, now)
    timeView?.text = timeText(s, now)
  }

  private fun timeText(s: SessionStore.Snapshot, now: Long): String {
    val t = Colors.hms(s.remaining(now))
    return if (s.paused && mode == Mode.BUBBLE) "⏸ $t" else t
  }

  /* ----- building the views ----- */

  private fun rebuild(s: SessionStore.Snapshot, now: Long) {
    val r = root ?: return
    r.removeAllViews()
    timeView = null
    when (mode) {
      Mode.BUBBLE -> r.addView(buildBubble(s, now))
      Mode.PANEL -> r.addView(buildPanel(s, now))
      Mode.AI -> r.addView(buildAiMenu())
      Mode.CONFIRM_STOP -> r.addView(buildConfirm())
    }
    builtKey = "$mode|${s.paused}|${s.attempts}"
    try {
      params?.let { wm.updateViewLayout(r, it) }
    } catch (ignored: Throwable) {
    }
  }

  private fun roundBg(fill: Int, stroke: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
    cornerRadius = radiusDp * dp
    setColor(fill)
    setStroke(maxOf(1, px(1f)), stroke)
  }

  private fun label(text: String, sp: Float, color: Int, serif: Boolean = false, bold: Boolean = false): TextView = TextView(ctx).apply {
    this.text = text
    textSize = sp
    setTextColor(color)
    typeface = Typeface.create(if (serif) Typeface.SERIF else Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
  }

  private fun button(title: String, fill: Int, textColor: Int, stroke: Int, onClick: () -> Unit): TextView = TextView(ctx).apply {
    text = title
    textSize = 14f
    gravity = Gravity.CENTER
    setTextColor(textColor)
    setTypeface(typeface, Typeface.BOLD)
    background = roundBg(fill, stroke, 14f)
    setPadding(px(14f), px(11f), px(14f), px(11f))
    isClickable = true
    setOnClickListener { onClick() }
  }

  private fun buildBubble(s: SessionStore.Snapshot, now: Long): View {
    val row = LinearLayout(ctx).apply {
      orientation = LinearLayout.HORIZONTAL
      gravity = Gravity.CENTER_VERTICAL
      background = roundBg((0xF2 shl 24) or (Colors.SURFACE and 0xFFFFFF), (Colors.GOLD and 0xFFFFFF) or (0x66 shl 24), 999f)
      setPadding(px(14f), px(9f), px(16f), px(9f))
      elevation = 6f * dp
    }
    val dot = View(ctx).apply {
      background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (s.paused) Colors.DIM else Colors.GOLD)
      }
      layoutParams = LinearLayout.LayoutParams(px(8f), px(8f)).apply { rightMargin = px(9f) }
    }
    val time = label(timeText(s, now), 16f, if (s.paused) Colors.DIM else Colors.TEXT, serif = true, bold = true).apply {
      fontFeatureSettings = "tnum"
    }
    timeView = time
    row.addView(dot)
    row.addView(time)
    return row
  }

  private fun buildPanel(s: SessionStore.Snapshot, now: Long): View {
    val col = panelColumn()
    val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    header.addView(label(if (s.paused) "Paused" else "Focusing", 13f, Colors.DIM).apply {
      layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    })
    header.addView(label("Close", 13f, Colors.GOLD, bold = true).apply {
      setPadding(px(10f), px(4f), 0, px(4f))
      isClickable = true
      setOnClickListener { setMode(Mode.BUBBLE) }
    })
    col.addView(header)

    val time = label(timeText(s, now), 38f, if (s.paused) Colors.DIM else Colors.TEXT, serif = true).apply {
      gravity = Gravity.CENTER
      fontFeatureSettings = "tnum"
      setPadding(0, px(6f), 0, px(2f))
    }
    timeView = time
    col.addView(time)
    if (s.attempts > 0) {
      col.addView(label("${s.attempts} blocked attempt${if (s.attempts == 1) "" else "s"}", 12f, Colors.FAINT).apply {
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, px(4f))
      })
    }

    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, px(10f), 0, 0) }
    val primary = if (s.paused) {
      button("Resume", Colors.GOLD, Colors.ON_ACCENT, Colors.GOLD) { actions.resume() }
    } else {
      button("Pause", Colors.SURFACE_HI, Colors.TEXT, Colors.BORDER) { actions.pause() }
    }
    primary.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = px(8f) }
    val ai = button("AI Help", Colors.SURFACE_HI, Colors.GOLD, Colors.BORDER) { setMode(Mode.AI) }
    ai.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    row.addView(primary)
    row.addView(ai)
    col.addView(row)

    val stop = button("Stop session", 0x00000000, Colors.DANGER, Colors.DANGER) { setMode(Mode.CONFIRM_STOP) }
    stop.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8f) }
    col.addView(stop)
    return col
  }

  private fun buildAiMenu(): View {
    val col = panelColumn()
    col.addView(label("AI Help", 18f, Colors.TEXT, serif = true))
    col.addView(label("Your timer keeps running. Nothing is sent until you choose a question.", 12f, Colors.DIM).apply {
      setPadding(0, px(4f), 0, px(10f))
    })
    col.addView(button("Capture this screen", Colors.GOLD, Colors.ON_ACCENT, Colors.GOLD) {
      setMode(Mode.BUBBLE)
      actions.captureScreen()
    })
    val typed = button("Type or upload", Colors.SURFACE_HI, Colors.TEXT, Colors.BORDER) {
      setMode(Mode.BUBBLE)
      actions.openAssist()
    }
    typed.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8f) }
    col.addView(typed)
    val back = button("Back", 0x00000000, Colors.DIM, 0x00000000) { setMode(Mode.PANEL) }
    back.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(4f) }
    col.addView(back)
    return col
  }

  private fun buildConfirm(): View {
    val col = panelColumn()
    col.addView(label("Stop this session?", 18f, Colors.TEXT, serif = true))
    col.addView(label("The time so far is logged. App blocking and the floating timer end.", 12f, Colors.DIM).apply {
      setPadding(0, px(4f), 0, px(10f))
    })
    col.addView(button("Keep going", Colors.GOLD, Colors.ON_ACCENT, Colors.GOLD) { setMode(Mode.PANEL) })
    val stop = button("Stop session", 0x00000000, Colors.DANGER, Colors.DANGER) {
      setMode(Mode.BUBBLE)
      actions.stop()
    }
    stop.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8f) }
    col.addView(stop)
    return col
  }

  private fun panelColumn(): LinearLayout = LinearLayout(ctx).apply {
    orientation = LinearLayout.VERTICAL
    background = roundBg(Colors.SURFACE, Colors.BORDER, 22f)
    setPadding(px(18f), px(14f), px(18f), px(16f))
    elevation = 8f * dp
    layoutParams = FrameLayout.LayoutParams(px(268f), ViewGroup.LayoutParams.WRAP_CONTENT)
  }

  private fun setMode(next: Mode) {
    val lp = params ?: return
    val wasBubble = mode == Mode.BUBBLE
    if (wasBubble && next != Mode.BUBBLE) {
      bubbleX = lp.x
      bubbleY = lp.y
      lp.x = clampX(lp.x, px(268f))
      lp.y = clampY(lp.y, px(260f))
    } else if (!wasBubble && next == Mode.BUBBLE) {
      lp.x = bubbleX
      lp.y = bubbleY
    }
    mode = next
    builtKey = "" // force a rebuild on the next render
    val s = store.read()
    rebuild(s, System.currentTimeMillis())
  }

  /* ----- dragging ----- */

  private fun clampX(x: Int, width: Int): Int = x.coerceIn(0, maxOf(0, ctx.resources.displayMetrics.widthPixels - width))
  private fun clampY(y: Int, height: Int): Int = y.coerceIn(0, maxOf(0, ctx.resources.displayMetrics.heightPixels - height))

  private val touch = object : View.OnTouchListener {
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false

    override fun onTouch(v: View, e: MotionEvent): Boolean {
      val lp = params ?: return false
      when (e.actionMasked) {
        MotionEvent.ACTION_DOWN -> {
          downX = e.rawX
          downY = e.rawY
          startX = lp.x
          startY = lp.y
          dragging = false
          return true
        }
        MotionEvent.ACTION_MOVE -> {
          val dx = e.rawX - downX
          val dy = e.rawY - downY
          if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
          if (dragging) {
            val w = if (mode == Mode.BUBBLE) v.width else px(268f)
            val h = if (mode == Mode.BUBBLE) v.height else px(60f)
            lp.x = clampX(startX + dx.toInt(), w)
            lp.y = clampY(startY + dy.toInt(), h)
            try {
              wm.updateViewLayout(v, lp)
            } catch (ignored: Throwable) {
            }
          }
          return true
        }
        MotionEvent.ACTION_UP -> {
          if (dragging) {
            if (mode == Mode.BUBBLE) store.saveOverlay(lp.x, lp.y)
          } else if (mode == Mode.BUBBLE) {
            setMode(Mode.PANEL)
          }
          return true
        }
        MotionEvent.ACTION_CANCEL -> return true
      }
      return false
    }
  }
}
