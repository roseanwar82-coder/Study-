package expo.modules.majestofocus

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Full-screen reminder that replaces a blocked app. It lives in its own task, so finishing it always shows
 * the home screen or Majesto rather than the blocked app underneath.
 */
class BlockActivity : Activity() {
  companion object {
    const val EXTRA_LABEL = "label"
  }

  private val handler = Handler(Looper.getMainLooper())
  private lateinit var timeView: TextView
  private lateinit var attemptsView: TextView

  private val tick = object : Runnable {
    override fun run() {
      render()
      handler.postDelayed(this, 1000L)
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    window.statusBarColor = Colors.BG
    window.navigationBarColor = Colors.BG
    setContentView(buildContent(intent?.getStringExtra(EXTRA_LABEL) ?: "This app"))
    render()
  }

  override fun onNewIntent(intent: android.content.Intent?) {
    super.onNewIntent(intent)
    setIntent(intent)
  }

  override fun onResume() {
    super.onResume()
    handler.post(tick)
  }

  override fun onPause() {
    handler.removeCallbacks(tick)
    super.onPause()
  }

  @Deprecated("Back goes home, never back into the blocked app")
  override fun onBackPressed() {
    goHome()
  }

  private fun render() {
    val s = SessionStore(this).read()
    if (!s.active) {
      // The session ended while this screen was up. Nothing left to block.
      finishAndRemoveTask()
      return
    }
    timeView.text = if (s.paused) "Paused" else Colors.hms(s.remaining(System.currentTimeMillis()))
    attemptsView.text = if (s.attempts > 1) "${s.attempts} blocked attempts so far" else ""
  }

  private fun buildContent(label: String): View {
    val dp = resources.displayMetrics.density
    val root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      gravity = Gravity.CENTER
      setBackgroundColor(Colors.BG)
      setPadding((28 * dp).toInt(), (40 * dp).toInt(), (28 * dp).toInt(), (40 * dp).toInt())
      layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }
    fun text(value: String, sp: Float, color: Int, serif: Boolean = false, bold: Boolean = false) = TextView(this).apply {
      this.text = value
      textSize = sp
      setTextColor(color)
      gravity = Gravity.CENTER
      typeface = Typeface.create(if (serif) Typeface.SERIF else Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }
    root.addView(text("Focus mode is on", 28f, Colors.TEXT, serif = true))
    root.addView(text("$label is blocked until your session ends.", 16f, Colors.DIM).apply { setPadding(0, (12 * dp).toInt(), 0, (24 * dp).toInt()) })
    timeView = text("", 44f, Colors.GOLD, serif = true)
    root.addView(timeView)
    attemptsView = text("", 13f, Colors.FAINT).apply { setPadding(0, (8 * dp).toInt(), 0, (32 * dp).toInt()) }
    root.addView(attemptsView)

    fun button(title: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
      this.text = title
      textSize = 16f
      gravity = Gravity.CENTER
      setTypeface(typeface, Typeface.BOLD)
      setTextColor(if (filled) Colors.ON_ACCENT else Colors.TEXT)
      background = GradientDrawable().apply {
        cornerRadius = 16 * dp
        setColor(if (filled) Colors.GOLD else Colors.SURFACE_HI)
        setStroke((1 * dp).toInt().coerceAtLeast(1), if (filled) Colors.GOLD else Colors.BORDER)
      }
      setPadding((22 * dp).toInt(), (14 * dp).toInt(), (22 * dp).toInt(), (14 * dp).toInt())
      isClickable = true
      setOnClickListener { onClick() }
      layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = (12 * dp).toInt()
      }
    }
    root.addView(button("Back to Majesto", true) { Launch.openApp(this); finishAndRemoveTask() })
    root.addView(button("Go to home screen", false) { goHome() })
    return root
  }

  private fun goHome() {
    Launch.goHome(this)
    finishAndRemoveTask()
  }
}

/** The app's own colours, so native screens match the JS theme in src/ui/theme.ts. */
object Colors {
  val BG: Int = Color.parseColor("#0D0C10")
  val SURFACE: Int = Color.parseColor("#16141B")
  val SURFACE_HI: Int = Color.parseColor("#1F1C26")
  val BORDER: Int = Color.parseColor("#2B2733")
  val TEXT: Int = Color.parseColor("#F1E9D8")
  val DIM: Int = Color.parseColor("#A9A092")
  val FAINT: Int = Color.parseColor("#6E675C")
  val GOLD: Int = Color.parseColor("#E0B45A")
  val DANGER: Int = Color.parseColor("#E5645B")
  val ON_ACCENT: Int = Color.parseColor("#1A1408")

  fun hms(ms: Long): String {
    val total = maxOf(0L, (ms + 999L) / 1000L)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return String.format("%02d:%02d:%02d", h, m, s)
  }
}
