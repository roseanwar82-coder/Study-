package expo.modules.majestofocus

import android.content.Context
import android.content.SharedPreferences

/**
 * The native copy of the running focus session. It lives in SharedPreferences so that it survives the
 * service being restarted by Android. The app (JS) store is still the source of truth for the timer;
 * this copy only changes by itself when the person presses a control on the floating timer.
 *
 * Timer math is identical to src/core/focus.ts: elapsed = (pausedAt ?: now) - startedAt - pausedTotalMs.
 */
class SessionStore(ctx: Context) {
  private companion object {
    /** One lock for every instance: the service, module and overlay each create their own SessionStore. */
    val LOCK = Any()
  }

  private val p: SharedPreferences = ctx.applicationContext.getSharedPreferences("majesto_focus_session", Context.MODE_PRIVATE)

  data class Snapshot(
    val active: Boolean,
    val id: String,
    val startedAt: Long,
    val plannedMs: Long,
    val pausedAt: Long, // -1 when running
    val pausedTotalMs: Long,
    val endedReason: String, // "", "stopped", "expired"
    val endedAt: Long,
    val pendingCommand: String, // "", "pause", "resume", "stop"
    val pendingAt: Long,
    val attempts: Int,
    val blocked: Set<String>,
    val floating: Boolean,
    val dnd: String,
  ) {
    val paused: Boolean get() = pausedAt > 0
    fun elapsed(now: Long): Long = maxOf(0L, (if (paused) pausedAt else now) - startedAt - pausedTotalMs)
    fun remaining(now: Long): Long = maxOf(0L, plannedMs - elapsed(now))
  }

  fun read(): Snapshot = Snapshot(
    active = p.getBoolean("active", false),
    id = p.getString("id", "") ?: "",
    startedAt = p.getLong("startedAt", 0L),
    plannedMs = p.getLong("plannedMs", 0L),
    pausedAt = p.getLong("pausedAt", -1L),
    pausedTotalMs = p.getLong("pausedTotalMs", 0L),
    endedReason = p.getString("endedReason", "") ?: "",
    endedAt = p.getLong("endedAt", 0L),
    pendingCommand = p.getString("pendingCommand", "") ?: "",
    pendingAt = p.getLong("pendingAt", 0L),
    attempts = p.getInt("attempts", 0),
    blocked = HashSet(p.getStringSet("blocked", emptySet()) ?: emptySet()),
    floating = p.getBoolean("floating", false),
    dnd = p.getString("dnd", "off") ?: "off",
  )

  /** Starts tracking a session. Replaces whatever was there. */
  fun begin(id: String, startedAt: Long, plannedMs: Long, pausedAt: Long, pausedTotalMs: Long, blocked: Set<String>, floating: Boolean, dnd: String) {
    p.edit()
      .putBoolean("active", true)
      .putString("id", id)
      .putLong("startedAt", startedAt)
      .putLong("plannedMs", plannedMs)
      .putLong("pausedAt", pausedAt)
      .putLong("pausedTotalMs", pausedTotalMs)
      .putString("endedReason", "")
      .putLong("endedAt", 0L)
      .putString("pendingCommand", "")
      .putLong("pendingAt", 0L)
      .putInt("attempts", 0)
      .putStringSet("blocked", HashSet(blocked))
      .putBoolean("floating", floating)
      .putString("dnd", dnd)
      .apply()
  }

  /** The app changed the timer (pause or resume) or its options. */
  fun update(startedAt: Long, plannedMs: Long, pausedAt: Long, pausedTotalMs: Long, blocked: Set<String>, floating: Boolean, dnd: String) {
    p.edit()
      .putLong("startedAt", startedAt)
      .putLong("plannedMs", plannedMs)
      .putLong("pausedAt", pausedAt)
      .putLong("pausedTotalMs", pausedTotalMs)
      .putStringSet("blocked", HashSet(blocked))
      .putBoolean("floating", floating)
      .putString("dnd", dnd)
      .apply()
  }

  fun markPaused(at: Long) {
    p.edit().putLong("pausedAt", at).apply()
  }

  fun markResumed(at: Long) = synchronized(LOCK) {
    val s = read()
    if (s.paused) {
      p.edit().putLong("pausedTotalMs", s.pausedTotalMs + maxOf(0L, at - s.pausedAt)).putLong("pausedAt", -1L).apply()
    }
  }

  fun markEnded(reason: String, at: Long) {
    p.edit().putBoolean("active", false).putString("endedReason", reason).putLong("endedAt", at).apply()
  }

  fun setPending(command: String, at: Long) {
    p.edit().putString("pendingCommand", command).putLong("pendingAt", at).apply()
  }

  fun clearPending() {
    p.edit().putString("pendingCommand", "").putLong("pendingAt", 0L).apply()
  }

  fun addAttempt(): Int = synchronized(LOCK) {
    val n = p.getInt("attempts", 0) + 1
    p.edit().putInt("attempts", n).apply()
    n
  }

  /** Forgets the session. Keeps the overlay position and any picture still waiting for the AI screen. */
  fun clear() {
    val e = p.edit()
    for (k in listOf(
      "active", "id", "startedAt", "plannedMs", "pausedAt", "pausedTotalMs", "endedReason", "endedAt",
      "pendingCommand", "pendingAt", "attempts", "blocked", "floating", "dnd",
    )) e.remove(k)
    e.apply()
  }

  /* ----- overlay position and the picture waiting for the AI screen ----- */

  fun overlayX(): Int = p.getInt("overlayX", -1)
  fun overlayY(): Int = p.getInt("overlayY", -1)
  fun saveOverlay(x: Int, y: Int) {
    p.edit().putInt("overlayX", x).putInt("overlayY", y).apply()
  }

  fun setPendingImage(path: String) {
    p.edit().putString("pendingImage", path).apply()
  }

  fun pendingImage(): String? = p.getString("pendingImage", null)

  fun takePendingImage(): String? = synchronized(LOCK) {
    val v = p.getString("pendingImage", null)
    if (v != null) p.edit().remove("pendingImage").apply()
    v
  }
}
