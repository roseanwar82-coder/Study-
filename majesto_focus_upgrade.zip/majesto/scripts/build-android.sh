#!/usr/bin/env bash
# One command from a fresh terminal (for example GitHub Codespaces) to an installable Android APK.
# Usage: bash scripts/build-android.sh
set -e
cd "$(dirname "$0")/.."
EAS="npx --yes eas-cli@latest"

echo "== 1/5 Installing packages (a few minutes) =="
npm install

echo "== 2/5 Aligning Expo package versions to SDK 57 =="
npx expo install --fix

echo "== 3/5 Checking the project =="
npx expo-doctor || echo "expo-doctor reported something (see above). Continuing anyway; if the build fails, send that message to Claude."

echo "== 4/5 Signing in to Expo and linking the project =="
$EAS whoami >/dev/null 2>&1 || $EAS login
$EAS init

git add -A
git -c user.name="Majesto" -c user.email="dev@majesto.local" commit -q -m "Link EAS project" || true

echo "== 5/5 Building the Android APK in Expo's cloud =="
echo "Say yes if asked to generate a new Android keystore."
$EAS build --platform android --profile preview

echo
echo "Done. Open the build link printed above on your Android phone to download and install the APK."
