import * as Haptics from 'expo-haptics';
import { store } from '@/store';

function run(fn: () => Promise<void>) {
  if (!store.get().settings.haptics) return;
  fn().catch(() => {});
}

export const haptic = {
  tap: () => run(() => Haptics.selectionAsync()),
  press: () => run(() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)),
  success: () => run(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)),
  warn: () => run(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)),
  error: () => run(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error)),
};
