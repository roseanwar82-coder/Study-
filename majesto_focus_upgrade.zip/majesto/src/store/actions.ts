import type {
  AppState, Card, DrillKind, DrillResult, FocusSession, Grade, Settings, Task,
} from '@/core/types';
import { createTimer, buildSession, pauseTimer, resumeTimer, type TimerInput } from '@/core/focus';
import { newSrsState, schedule } from '@/core/srs';
import { dayKey } from '@/core/time';
import { xpForDrill, xpForReview } from '@/core/xp';
import { finalize, withActivity, withXp } from './finalize';
import { DECK_COLORS, createInitialPersisted, migrate, toPersisted } from './state';
import { loadRaw, type StorageAdapter } from './persistence';
import type { Store } from './store';

export interface Deps {
  now: () => number;
  id: (prefix?: string) => string;
}

export interface FinishResult {
  kind: 'focus' | 'break';
  session: FocusSession | null;
  xp: number;
}

export interface DrillOutcome {
  kind: DrillKind;
  points: number;
  summary: string;
  accuracy: number | null;
  durationMs: number;
  level: number;
  nextLevel?: number;
}

export interface DrillRecord {
  result: DrillResult;
  isPersonalBest: boolean;
  previousBest: number;
}

const MAX_SESSIONS = 500;
const MAX_DRILL_RESULTS = 200;

export function createActions(store: Store<AppState>, deps: Deps) {
  const { now, id } = deps;

  /** Apply a change, then run achievements and level-up checks. */
  function commit(fn: (s: AppState, t: number) => AppState) {
    store.set((prev) => {
      const t = now();
      return finalize(prev, fn(prev, t), t, id);
    });
  }

  function addCards(deckId: string, items: { front: string; back: string }[]): number {
    const box = { n: 0 };
    commit((s, t) => {
      if (!s.decks.some((d) => d.id === deckId)) return s;
      const fresh: Card[] = [];
      for (const item of items) {
        const front = item.front.trim();
        const back = item.back.trim();
        if (!front || !back) continue;
        fresh.push({
          id: id('card'),
          deckId,
          front,
          back,
          createdAt: t + fresh.length,
          srs: newSrsState(t),
        });
      }
      box.n = fresh.length;
      return fresh.length ? { ...s, cards: [...s.cards, ...fresh] } : s;
    });
    return box.n;
  }

  return {
    /* ---------- lifecycle ---------- */

    async hydrate(storage: StorageAdapter, key?: string) {
      const persisted = migrate(await loadRaw(storage, key), now(), id);
      store.set((s) => ({ ...s, ...persisted, hydrated: true, toasts: [] }));
    },

    completeOnboarding(name: string, dailyFocusGoalMin: number) {
      commit((s) => ({
        ...s,
        profile: { ...s.profile, name: name.trim(), onboarded: true },
        settings: { ...s.settings, dailyFocusGoalMin },
      }));
    },

    setName(name: string) {
      commit((s) => ({ ...s, profile: { ...s.profile, name: name.trim() } }));
    },

    updateSettings(patch: Partial<Settings>) {
      commit((s) => ({ ...s, settings: { ...s.settings, ...patch } }));
    },

    /** Show a one-line message in the toast host. */
    pushToast(title: string, body: string) {
      store.set((s) => ({
        ...s,
        toasts: [...s.toasts, { id: id('toast'), kind: 'info' as const, title, body }].slice(-5),
      }));
    },

    dismissToast(toastId: string) {
      store.set((s) => ({ ...s, toasts: s.toasts.filter((t) => t.id !== toastId) }));
    },

    /** Wipes everything, keeps the app running, and sends the person back through onboarding. */
    resetAll() {
      const t = now();
      store.set((s) => ({ ...s, ...createInitialPersisted(t, id), hydrated: true, toasts: [] }));
    },

    exportJson(): string {
      return JSON.stringify(toPersisted(store.get()), null, 2);
    },

    /* ---------- intentions ---------- */

    addTask(title: string): string | null {
      const clean = title.trim();
      if (!clean) return null;
      const task: Task = { id: id('task'), title: clean, day: dayKey(now()), createdAt: now(), doneAt: null, focusMs: 0 };
      commit((s) => ({ ...s, tasks: [...s.tasks, task] }));
      return task.id;
    },

    toggleTask(taskId: string) {
      commit((s, t) => {
        const task = s.tasks.find((x) => x.id === taskId);
        if (!task) return s;
        if (!task.doneAt) {
          const n = { ...s, tasks: s.tasks.map((x) => (x.id === taskId ? { ...x, doneAt: t } : x)) };
          return withActivity(n, dayKey(t), { tasksDone: 1 });
        }
        const doneDay = dayKey(task.doneAt);
        const had = s.activity[doneDay]?.tasksDone ?? 0;
        const n = { ...s, tasks: s.tasks.map((x) => (x.id === taskId ? { ...x, doneAt: null } : x)) };
        return had > 0 ? withActivity(n, doneDay, { tasksDone: -1 }) : n;
      });
    },

    renameTask(taskId: string, title: string) {
      const clean = title.trim();
      if (!clean) return;
      commit((s) => ({ ...s, tasks: s.tasks.map((x) => (x.id === taskId ? { ...x, title: clean } : x)) }));
    },

    deleteTask(taskId: string) {
      commit((s) => ({
        ...s,
        tasks: s.tasks.filter((x) => x.id !== taskId),
        timer: s.timer?.taskId === taskId ? { ...s.timer, taskId: null } : s.timer,
      }));
    },

    /* ---------- focus ---------- */

    startTimer(input: TimerInput) {
      commit((s, t) => (s.timer ? s : { ...s, timer: createTimer(input, t, id('timer')) }));
    },

    /** `at` lets the Android overlay report the moment the button was actually pressed. */
    pauseTimer(at?: number) {
      commit((s, t) => (s.timer ? { ...s, timer: pauseTimer(s.timer, at === undefined ? t : Math.min(at, t)) } : s));
    },

    resumeTimer(at?: number) {
      commit((s, t) => (s.timer ? { ...s, timer: resumeTimer(s.timer, at === undefined ? t : Math.min(at, t)) } : s));
    },

    addDistraction() {
      commit((s) => (s.timer ? { ...s, timer: { ...s.timer, distractions: s.timer.distractions + 1 } } : s));
    },

    discardTimer() {
      commit((s) => (s.timer ? { ...s, timer: null } : s));
    },

    /**
     * Ends the running timer. `completed` is true when the clock ran out.
     * `at` is the moment it really ended when that was earlier than now (a stop from the floating timer).
     */
    finishTimer(completed: boolean, at?: number): FinishResult | null {
      const box: { v: FinishResult | null } = { v: null };
      commit((s, now0) => {
        const t = at === undefined ? now0 : Math.min(at, now0);
        const timer = s.timer;
        if (!timer) return s;
        if (timer.kind === 'break') {
          box.v = { kind: 'break', session: null, xp: 0 };
          return { ...s, timer: null };
        }
        const session = buildSession(timer, t, completed, id('session'));
        if (!session) {
          box.v = { kind: 'focus', session: null, xp: 0 };
          return { ...s, timer: null };
        }
        let n: AppState = {
          ...s,
          timer: null,
          sessions: [...s.sessions, session].slice(-MAX_SESSIONS),
          tasks: timer.taskId
            ? s.tasks.map((x) => (x.id === timer.taskId ? { ...x, focusMs: x.focusMs + session.actualMs } : x))
            : s.tasks,
        };
        n = withActivity(n, session.dayKey, { focusMs: session.actualMs, sessions: 1 });
        n = withXp(n, session.dayKey, session.xp);
        box.v = { kind: 'focus', session, xp: session.xp };
        return n;
      });
      return box.v;
    },

    /* ---------- recall ---------- */

    addDeck(name: string, color?: string): string | null {
      const clean = name.trim();
      if (!clean) return null;
      const deckId = id('deck');
      commit((s, t) => ({
        ...s,
        decks: [...s.decks, { id: deckId, name: clean, color: color ?? DECK_COLORS[s.decks.length % DECK_COLORS.length], createdAt: t }],
      }));
      return deckId;
    },

    renameDeck(deckId: string, name: string) {
      const clean = name.trim();
      if (!clean) return;
      commit((s) => ({ ...s, decks: s.decks.map((d) => (d.id === deckId ? { ...d, name: clean } : d)) }));
    },

    deleteDeck(deckId: string) {
      commit((s) => ({
        ...s,
        decks: s.decks.filter((d) => d.id !== deckId),
        cards: s.cards.filter((c) => c.deckId !== deckId),
      }));
    },

    addCards,

    addCard(deckId: string, front: string, back: string): boolean {
      return addCards(deckId, [{ front, back }]) === 1;
    },

    updateCard(cardId: string, front: string, back: string) {
      const f = front.trim();
      const b = back.trim();
      if (!f || !b) return;
      commit((s) => ({ ...s, cards: s.cards.map((c) => (c.id === cardId ? { ...c, front: f, back: b } : c)) }));
    },

    deleteCard(cardId: string) {
      commit((s) => ({ ...s, cards: s.cards.filter((c) => c.id !== cardId) }));
    },

    gradeCard(cardId: string, grade: Grade): { xp: number; card: Card } | null {
      const box: { v: { xp: number; card: Card } | null } = { v: null };
      commit((s, t) => {
        const card = s.cards.find((c) => c.id === cardId);
        if (!card) return s;
        const srs = schedule(card.srs, grade, t);
        const updated: Card = { ...card, srs };
        const xp = xpForReview(grade);
        let n: AppState = { ...s, cards: s.cards.map((c) => (c.id === cardId ? updated : c)) };
        n = withActivity(n, dayKey(t), { reviews: 1, newCards: card.srs.phase === 'new' ? 1 : 0 });
        n = withXp(n, dayKey(t), xp);
        box.v = { xp, card: updated };
        return n;
      });
      return box.v;
    },

    /* ---------- drills ---------- */

    recordDrill(outcome: DrillOutcome): DrillRecord | null {
      const box: { v: DrillRecord | null } = { v: null };
      commit((s, t) => {
        const prevStats = s.drills.stats[outcome.kind];
        const previousBest = prevStats?.best ?? 0;
        const isPersonalBest = outcome.points > previousBest;
        const xp = xpForDrill(outcome.points, isPersonalBest && !!prevStats);
        const result: DrillResult = {
          id: id('drill'),
          kind: outcome.kind,
          at: t,
          dayKey: dayKey(t),
          points: outcome.points,
          summary: outcome.summary,
          accuracy: outcome.accuracy,
          durationMs: outcome.durationMs,
          level: outcome.level,
          xp,
        };
        let n: AppState = {
          ...s,
          drills: {
            results: [...s.drills.results, result].slice(-MAX_DRILL_RESULTS),
            stats: {
              ...s.drills.stats,
              [outcome.kind]: {
                best: Math.max(previousBest, outcome.points),
                bestAt: isPersonalBest ? t : prevStats?.bestAt ?? t,
                plays: (prevStats?.plays ?? 0) + 1,
                lastPlayedAt: t,
              },
            },
            levels:
              outcome.nextLevel === undefined
                ? s.drills.levels
                : { ...s.drills.levels, [outcome.kind]: outcome.nextLevel },
          },
        };
        n = withActivity(n, dayKey(t), { drills: 1 });
        n = withXp(n, dayKey(t), xp);
        box.v = { result, isPersonalBest: isPersonalBest && !!prevStats, previousBest };
        return n;
      });
      return box.v;
    },

    setDrillLevel(kind: DrillKind, level: number) {
      commit((s) => ({ ...s, drills: { ...s.drills, levels: { ...s.drills.levels, [kind]: level } } }));
    },
  };
}

export type Actions = ReturnType<typeof createActions>;
