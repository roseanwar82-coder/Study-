import { useCallback, useRef, useSyncExternalStore } from 'react';
import type { Store } from './store';

export function shallowEqual(a: unknown, b: unknown): boolean {
  if (Object.is(a, b)) return true;
  if (typeof a !== 'object' || typeof b !== 'object' || a === null || b === null) return false;
  const ka = Object.keys(a);
  const kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  return ka.every(
    (k) =>
      Object.prototype.hasOwnProperty.call(b, k) &&
      Object.is((a as Record<string, unknown>)[k], (b as Record<string, unknown>)[k]),
  );
}

/**
 * Subscribe a component to a slice of the store.
 * Selectors may return fresh arrays or objects: results are compared shallowly,
 * so the component only re-renders when the contents actually change.
 */
export function useSelector<S, R>(store: Store<S>, selector: (state: S) => R): R {
  const cache = useRef<{ state: S; selector: (s: S) => R; value: R } | null>(null);

  const getSnapshot = useCallback(() => {
    const state = store.get();
    const prev = cache.current;
    if (prev && prev.state === state && prev.selector === selector) return prev.value;
    const value = selector(state);
    if (prev && shallowEqual(prev.value, value)) {
      cache.current = { state, selector, value: prev.value };
      return prev.value;
    }
    cache.current = { state, selector, value };
    return value;
  }, [store, selector]);

  return useSyncExternalStore(store.subscribe, getSnapshot, getSnapshot);
}
