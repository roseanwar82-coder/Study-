import type { DayActivity, DayKey } from './types';
import { MINUTE, addDays, diffDays } from './time';

export const emptyActivity = (): DayActivity => ({
  focusMs: 0,
  sessions: 0,
  reviews: 0,
  newCards: 0,
  drills: 0,
  tasksDone: 0,
  xp: 0,
});

/** A day counts toward the streak if you did any one of these. */
export const STREAK_RULE = { focusMs: 10 * MINUTE, reviews: 10, drills: 1 };

export function isActiveDay(a: DayActivity | undefined): boolean {
  if (!a) return false;
  return a.focusMs >= STREAK_RULE.focusMs || a.reviews >= STREAK_RULE.reviews || a.drills >= STREAK_RULE.drills;
}

export interface StreakInfo {
  current: number;
  longest: number;
  activeToday: boolean;
  /** Streak is alive but today isn't done yet. */
  atRisk: boolean;
}

export function computeStreak(activity: Record<DayKey, DayActivity>, today: DayKey): StreakInfo {
  const activeToday = isActiveDay(activity[today]);
  let cursor = activeToday ? today : addDays(today, -1);
  let current = 0;
  while (isActiveDay(activity[cursor])) {
    current++;
    cursor = addDays(cursor, -1);
  }

  const days = Object.keys(activity).filter((k) => isActiveDay(activity[k])).sort();
  let longest = 0;
  let run = 0;
  let prev: DayKey | null = null;
  for (const k of days) {
    run = prev !== null && diffDays(prev, k) === 1 ? run + 1 : 1;
    longest = Math.max(longest, run);
    prev = k;
  }
  return { current, longest: Math.max(longest, current), activeToday, atRisk: !activeToday && current > 0 };
}
