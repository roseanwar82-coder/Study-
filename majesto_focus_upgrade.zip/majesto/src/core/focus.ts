import type { ActiveTimer, FocusSession, GuardConfig, TimerKind } from './types';
import { MINUTE, dayKey } from './time';
import { xpForFocus } from './xp';

export const MIN_CREDIT_MS = MINUTE;

export interface TimerInput {
  kind: TimerKind;
  minutes: number;
  taskId?: string | null;
  label?: string;
  guard?: GuardConfig | null;
}

export function createTimer(input: TimerInput, now: number, id: string): ActiveTimer {
  return {
    id,
    kind: input.kind,
    startedAt: now,
    plannedMs: Math.max(1, Math.round(input.minutes)) * MINUTE,
    pausedAt: null,
    pausedTotalMs: 0,
    taskId: input.taskId ?? null,
    label: (input.label ?? '').trim(),
    distractions: 0,
    ...(input.guard && input.kind === 'focus' ? { guard: input.guard } : {}),
  };
}

export function elapsedMs(t: ActiveTimer, now: number): number {
  const end = t.pausedAt ?? now;
  return Math.max(0, end - t.startedAt - t.pausedTotalMs);
}

export function remainingMs(t: ActiveTimer, now: number): number {
  return Math.max(0, t.plannedMs - elapsedMs(t, now));
}

export function isExpired(t: ActiveTimer, now: number): boolean {
  return elapsedMs(t, now) >= t.plannedMs;
}

export function pauseTimer(t: ActiveTimer, now: number): ActiveTimer {
  return t.pausedAt === null ? { ...t, pausedAt: now } : t;
}

export function resumeTimer(t: ActiveTimer, now: number): ActiveTimer {
  if (t.pausedAt === null) return t;
  return { ...t, pausedAt: null, pausedTotalMs: t.pausedTotalMs + (now - t.pausedAt) };
}

/**
 * Build the session record for a timer that just ended.
 * Returns null when the run was too short to earn credit (and wasn't completed).
 */
export function buildSession(t: ActiveTimer, now: number, completed: boolean, id: string): FocusSession | null {
  const actualMs = Math.min(elapsedMs(t, now), t.plannedMs);
  if (!completed && actualMs < MIN_CREDIT_MS) return null;
  const naturalEnd = t.startedAt + t.pausedTotalMs + t.plannedMs;
  const endedAt = completed ? Math.min(now, naturalEnd) : now;
  return {
    id,
    startedAt: t.startedAt,
    endedAt,
    plannedMs: t.plannedMs,
    actualMs,
    completed,
    taskId: t.taskId,
    label: t.label,
    distractions: t.distractions,
    dayKey: dayKey(endedAt),
    xp: xpForFocus(actualMs, completed, t.distractions),
  };
}
