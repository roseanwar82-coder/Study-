import type { DrillKind, PersistedState, Task } from './types';
import type { DayKey } from './types';
import { MINUTE, clamp01, dayKey, lastNDays, weekdayLetter } from './time';
import { emptyActivity, isActiveDay } from './streak';
import { deckCounts, type DeckCounts } from './srs';
import { DRILL_ORDER } from './drills';

export interface TodaySummary {
  key: DayKey;
  focusMs: number;
  reviews: number;
  drills: number;
  focusRatio: number;
  reviewRatio: number;
  drillRatio: number;
  overall: number;
}

export function todaySummary(s: PersistedState, now: number): TodaySummary {
  const key = dayKey(now);
  const a = s.activity[key] ?? emptyActivity();
  const g = s.settings;
  const focusRatio = clamp01(a.focusMs / (Math.max(1, g.dailyFocusGoalMin) * MINUTE));
  const reviewRatio = clamp01(a.reviews / Math.max(1, g.dailyReviewGoal));
  const drillRatio = clamp01(a.drills / Math.max(1, g.dailyDrillGoal));
  return {
    key,
    focusMs: a.focusMs,
    reviews: a.reviews,
    drills: a.drills,
    focusRatio,
    reviewRatio,
    drillRatio,
    overall: (focusRatio + reviewRatio + drillRatio) / 3,
  };
}

/** Today's tasks, plus anything still open from earlier days. Open first. */
export function todayTasks(s: PersistedState, key: DayKey): Task[] {
  const visible = s.tasks.filter((t) => t.day === key || (!t.doneAt && t.day < key));
  const open = visible.filter((t) => !t.doneAt).sort((a, b) => a.createdAt - b.createdAt);
  const done = visible.filter((t) => t.doneAt).sort((a, b) => (a.doneAt ?? 0) - (b.doneAt ?? 0));
  return [...open, ...done];
}

export function newCardsRemaining(s: PersistedState, now: number): number {
  const introduced = s.activity[dayKey(now)]?.newCards ?? 0;
  return Math.max(0, s.settings.newCardsPerDay - introduced);
}

export function countsForDeck(s: PersistedState, deckId: string | null, now: number): DeckCounts {
  const cards = deckId ? s.cards.filter((c) => c.deckId === deckId) : s.cards;
  return deckCounts(cards, now, newCardsRemaining(s, now));
}

export interface WeekDay {
  key: DayKey;
  letter: string;
  xp: number;
  ratio: number;
  active: boolean;
  isToday: boolean;
}

export function weekSeries(s: PersistedState, now: number): WeekDay[] {
  const today = dayKey(now);
  const keys = lastNDays(today, 7);
  const maxXp = Math.max(1, ...keys.map((k) => s.activity[k]?.xp ?? 0));
  return keys.map((k) => {
    const a = s.activity[k];
    const xp = a?.xp ?? 0;
    return { key: k, letter: weekdayLetter(k), xp, ratio: xp / maxXp, active: isActiveDay(a), isToday: k === today };
  });
}

/** Least recently played drill; never-played drills come first. */
export function recommendedDrill(s: PersistedState): DrillKind {
  let best: DrillKind = DRILL_ORDER[0];
  let bestTime = Infinity;
  for (const kind of DRILL_ORDER) {
    const t = s.drills.stats[kind]?.lastPlayedAt ?? 0;
    if (t < bestTime) {
      best = kind;
      bestTime = t;
    }
  }
  return best;
}
