import type { Card, Grade, SrsState } from './types';
import { MINUTE, addDays, dayKey, diffDays, startOfDay } from './time';

/**
 * Spaced repetition scheduler: SM-2 style ease/interval growth for review cards,
 * with short learning steps for new and lapsed cards.
 */
export const GRADES: Grade[] = ['again', 'hard', 'good', 'easy'];
export const LEARNING_STEPS_MIN = [1, 10];
export const GRADUATING_INTERVAL_DAYS = 1;
export const EASY_INTERVAL_DAYS = 4;
export const STARTING_EASE = 2.5;
export const MIN_EASE = 1.3;
export const MAX_INTERVAL_DAYS = 3650;
export const LEARN_AHEAD_MIN = 20;

const round2 = (n: number) => Math.round(n * 100) / 100;

export function newSrsState(now: number): SrsState {
  return {
    phase: 'new',
    step: 0,
    ease: STARTING_EASE,
    intervalDays: 0,
    reps: 0,
    lapses: 0,
    due: now,
    lastReviewedAt: null,
  };
}

/** Review cards fall due at the start of a local day, not a wall-clock instant. */
function dueInDays(now: number, days: number): number {
  return startOfDay(addDays(dayKey(now), days));
}

export function schedule(prev: SrsState, grade: Grade, now: number): SrsState {
  const base: SrsState = { ...prev, reps: prev.reps + 1, lastReviewedAt: now };
  return prev.phase === 'review' ? scheduleReview(base, grade, now) : scheduleLearning(base, grade, now);
}

function scheduleLearning(s: SrsState, grade: Grade, now: number): SrsState {
  const steps = LEARNING_STEPS_MIN;
  const step = s.phase === 'new' ? 0 : s.step;
  const relearnInterval = s.intervalDays; // > 0 only for lapsed cards
  const graduate = (interval: number): SrsState => ({
    ...s,
    phase: 'review',
    step: 0,
    intervalDays: Math.min(MAX_INTERVAL_DAYS, interval),
    due: dueInDays(now, interval),
  });

  switch (grade) {
    case 'again':
      return { ...s, phase: 'learning', step: 0, due: now + steps[0] * MINUTE };
    case 'hard':
      return { ...s, phase: 'learning', step, due: now + steps[step] * MINUTE };
    case 'good': {
      const next = step + 1;
      if (next >= steps.length) return graduate(relearnInterval > 0 ? relearnInterval : GRADUATING_INTERVAL_DAYS);
      return { ...s, phase: 'learning', step: next, due: now + steps[next] * MINUTE };
    }
    case 'easy':
      return graduate(Math.max(relearnInterval + 1, EASY_INTERVAL_DAYS));
  }
}

function scheduleReview(s: SrsState, grade: Grade, now: number): SrsState {
  const iv = s.intervalDays;
  const finish = (interval: number, ease: number): SrsState => {
    const capped = Math.min(MAX_INTERVAL_DAYS, interval);
    return { ...s, ease: round2(Math.max(MIN_EASE, ease)), intervalDays: capped, due: dueInDays(now, capped) };
  };
  switch (grade) {
    case 'again':
      return {
        ...s,
        phase: 'learning',
        step: 0,
        lapses: s.lapses + 1,
        ease: round2(Math.max(MIN_EASE, s.ease - 0.2)),
        intervalDays: Math.max(1, Math.round(iv * 0.3)),
        due: now + LEARNING_STEPS_MIN[0] * MINUTE,
      };
    case 'hard':
      return finish(Math.max(iv + 1, Math.round(iv * 1.2)), s.ease - 0.15);
    case 'good':
      return finish(Math.max(iv + 1, Math.round(iv * s.ease)), s.ease);
    case 'easy':
      return finish(Math.max(iv + 2, Math.round(iv * s.ease * 1.3)), s.ease + 0.15);
  }
}

export function isDue(s: SrsState, now: number): boolean {
  return s.phase !== 'new' && s.due <= now;
}

/* ---------- Queues and counts ---------- */

export interface QueueOptions {
  newLimit: number;
  reviewLimit?: number;
  learnAheadMin?: number;
}

export interface QueueParts {
  learning: Card[];
  review: Card[];
  fresh: Card[];
}

export function partition(cards: Card[], now: number, opts: QueueOptions): QueueParts {
  const learnAhead = (opts.learnAheadMin ?? LEARN_AHEAD_MIN) * MINUTE;
  const learning = cards
    .filter((c) => c.srs.phase === 'learning' && c.srs.due <= now + learnAhead)
    .sort((a, b) => a.srs.due - b.srs.due);
  const review = cards
    .filter((c) => c.srs.phase === 'review' && c.srs.due <= now)
    .sort((a, b) => a.srs.due - b.srs.due)
    .slice(0, opts.reviewLimit ?? 200);
  const fresh = cards
    .filter((c) => c.srs.phase === 'new')
    .sort((a, b) => a.createdAt - b.createdAt)
    .slice(0, Math.max(0, opts.newLimit));
  return { learning, review, fresh };
}

/** Card ids in the order they should be studied: learning, then due reviews, then new. */
export function buildQueue(cards: Card[], now: number, opts: QueueOptions): string[] {
  const { learning, review, fresh } = partition(cards, now, opts);
  return [...learning, ...review, ...fresh].map((c) => c.id);
}

export interface DeckCounts {
  new: number;
  learning: number;
  review: number;
  total: number;
}

export function deckCounts(cards: Card[], now: number, newLimit: number): DeckCounts {
  const p = partition(cards, now, { newLimit });
  return {
    new: p.fresh.length,
    learning: p.learning.length,
    review: p.review.length,
    total: p.fresh.length + p.learning.length + p.review.length,
  };
}

/* ---------- Labels ---------- */

export function formatDays(days: number): string {
  if (days < 30) return `${days}d`;
  if (days < 365) return `${(days / 30).toFixed(1).replace(/\.0$/, '')}mo`;
  return `${(days / 365).toFixed(1).replace(/\.0$/, '')}y`;
}

function formatShortDelay(ms: number): string {
  const mins = Math.max(1, Math.round(ms / MINUTE));
  return mins < 60 ? `${mins}m` : `${Math.round(mins / 60)}h`;
}

/** Interval a grade would produce, as shown on the answer buttons. */
export function intervalLabel(next: SrsState, now: number): string {
  return next.phase === 'review' ? formatDays(next.intervalDays) : formatShortDelay(next.due - now);
}

export function previewIntervals(s: SrsState, now: number): Record<Grade, string> {
  const out = {} as Record<Grade, string>;
  for (const g of GRADES) out[g] = intervalLabel(schedule(s, g, now), now);
  return out;
}

/** Status label for a card in a list: New, Due, Tomorrow, in 5d... */
export function dueLabel(s: SrsState, now: number): string {
  if (s.phase === 'new') return 'New';
  if (s.due <= now) return 'Due';
  if (s.phase === 'learning') return `in ${formatShortDelay(s.due - now)}`;
  const days = diffDays(dayKey(now), dayKey(s.due));
  return days <= 1 ? 'Tomorrow' : `in ${formatDays(days)}`;
}

/* ---------- Bulk import ---------- */

export interface ParsedCards {
  cards: { front: string; back: string }[];
  skipped: number;
}

/** One card per line: "front :: back" or "front<TAB>back". */
export function parseBulkCards(text: string): ParsedCards {
  const cards: { front: string; back: string }[] = [];
  let skipped = 0;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    let idx = line.indexOf('::');
    let sepLen = 2;
    if (idx < 0) {
      idx = line.indexOf('\t');
      sepLen = 1;
    }
    if (idx < 0) {
      skipped++;
      continue;
    }
    const front = line.slice(0, idx).trim();
    const back = line.slice(idx + sepLen).trim();
    if (!front || !back) {
      skipped++;
      continue;
    }
    cards.push({ front, back });
  }
  return { cards, skipped };
}

