import type { Rng } from '../rng';
import { clamp01 } from '../time';

export type StroopColorId = 'red' | 'green' | 'blue' | 'yellow';

export const STROOP_COLORS: { id: StroopColorId; name: string; hex: string }[] = [
  { id: 'red', name: 'Red', hex: '#E5484D' },
  { id: 'green', name: 'Green', hex: '#46B97F' },
  { id: 'blue', name: 'Blue', hex: '#4F8FF7' },
  { id: 'yellow', name: 'Yellow', hex: '#F2C94C' },
];

export interface StroopTrial {
  word: StroopColorId;
  ink: StroopColorId;
}

export const STROOP_TRIALS = 24;

/** About 30% congruent trials, the rest deliberately mismatched. */
export function generateStroopTrials(rng: Rng, count = STROOP_TRIALS): StroopTrial[] {
  const ids = STROOP_COLORS.map((c) => c.id);
  const trials: StroopTrial[] = [];
  for (let i = 0; i < count; i++) {
    const word = rng.pick(ids);
    if (rng.chance(0.3)) {
      trials.push({ word, ink: word });
    } else {
      const others = ids.filter((id) => id !== word);
      trials.push({ word, ink: rng.pick(others) });
    }
  }
  return trials;
}

export interface StroopAnswer {
  correct: boolean;
  rtMs: number;
}

export interface StroopScore {
  points: number;
  accuracy: number;
  meanRtMs: number | null;
  summary: string;
}

const FAST_MS = 700;
const SLOW_MS = 2200;

export function scoreStroop(answers: StroopAnswer[]): StroopScore {
  if (answers.length === 0) return { points: 0, accuracy: 0, meanRtMs: null, summary: 'No answers' };
  const correct = answers.filter((a) => a.correct);
  const accuracy = correct.length / answers.length;
  const meanRtMs = correct.length ? correct.reduce((s, a) => s + a.rtMs, 0) / correct.length : null;
  const speed = meanRtMs === null ? 0 : clamp01((SLOW_MS - meanRtMs) / (SLOW_MS - FAST_MS));
  const norm = clamp01(accuracy * accuracy * (0.4 + 0.6 * speed));
  const rtText = meanRtMs === null ? 'no correct answers' : `${Math.round(meanRtMs)} ms average`;
  return {
    points: Math.round(1000 * norm),
    accuracy,
    meanRtMs,
    summary: `${correct.length}/${answers.length} correct, ${rtText}`,
  };
}
