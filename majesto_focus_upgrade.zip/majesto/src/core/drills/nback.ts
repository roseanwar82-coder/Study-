import type { Rng } from '../rng';
import { clamp01 } from '../time';

export const NBACK_LETTERS = 'BCDFGKLMPRST'.split('');
export const NBACK_TRIALS = 22;
export const NBACK_MAX_LEVEL = 4;

export interface NBackSequence {
  stimuli: string[];
  targets: boolean[];
}

/** A stimulus is a target when it equals the one shown n steps earlier. About 30% of scorable trials are targets. */
export function generateNBack(rng: Rng, n: number, trials = NBACK_TRIALS): NBackSequence {
  const stimuli: string[] = [];
  for (let i = 0; i < trials; i++) {
    if (i < n) {
      stimuli.push(rng.pick(NBACK_LETTERS));
    } else if (rng.chance(0.3)) {
      stimuli.push(stimuli[i - n]);
    } else {
      stimuli.push(rng.pick(NBACK_LETTERS.filter((l) => l !== stimuli[i - n])));
    }
  }
  const targets = stimuli.map((s, i) => i >= n && s === stimuli[i - n]);
  return { stimuli, targets };
}

export interface NBackTrial {
  target: boolean;
  responded: boolean;
}

export interface NBackScore {
  hits: number;
  misses: number;
  falseAlarms: number;
  correctRejections: number;
  balanced: number;
  points: number;
  nextLevel: number;
  summary: string;
}

/** The first n trials can never be targets, so they are ignored. */
export function scoreNBack(n: number, trials: NBackTrial[]): NBackScore {
  const scorable = trials.slice(n);
  let hits = 0, misses = 0, falseAlarms = 0, correctRejections = 0;
  for (const t of scorable) {
    if (t.target) t.responded ? hits++ : misses++;
    else t.responded ? falseAlarms++ : correctRejections++;
  }
  const targets = hits + misses;
  const nonTargets = falseAlarms + correctRejections;
  const hitRate = targets > 0 ? hits / targets : 1;
  const faRate = nonTargets > 0 ? falseAlarms / nonTargets : 0;
  const balanced = (hitRate + (1 - faRate)) / 2;
  const nextLevel = balanced >= 0.85 ? Math.min(NBACK_MAX_LEVEL, n + 1) : balanced < 0.6 ? Math.max(1, n - 1) : n;
  return {
    hits,
    misses,
    falseAlarms,
    correctRejections,
    balanced,
    points: Math.round(1000 * clamp01((balanced - 0.5) / 0.5)),
    nextLevel,
    summary: `${n}-back: ${hits}/${targets} matches found, ${falseAlarms} false alarm${falseAlarms === 1 ? '' : 's'}`,
  };
}
