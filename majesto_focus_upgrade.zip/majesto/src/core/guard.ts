import type { ActiveTimer, DndMode, GuardConfig, Settings } from './types';
import { isExpired } from './focus';

/* ------------------------------------------------------------------ */
/* Shapes shared with the Android module (modules/majesto-focus).      */
/* ------------------------------------------------------------------ */

/** The timer as the native side stores it. Same fields, same math as `core/focus.ts`. */
export interface NativeTimer {
  id: string;
  startedAt: number;
  plannedMs: number;
  pausedAt: number | null;
  pausedTotalMs: number;
}

export interface GuardOptions {
  blockedPackages: string[];
  floatingTimer: boolean;
  dndMode: DndMode;
}

export type NativeCommand = 'pause' | 'resume' | 'stop';

export interface NativeSession {
  active: boolean;
  id: string | null;
  startedAt: number;
  plannedMs: number;
  pausedAt: number | null;
  pausedTotalMs: number;
  /** Why the native side ended the session by itself, if it did. */
  endedReason: 'stopped' | 'expired' | null;
  endedAt: number | null;
  /** A press on the floating timer or the notification that JS has not applied yet. */
  pendingCommand: NativeCommand | null;
  pendingAt: number | null;
  blockedAttempts: number;
}

export interface GuardPermissions {
  overlay: boolean;
  usageAccess: boolean;
  accessibility: boolean;
  notificationPolicy: boolean;
  notifications: boolean;
}

export const EMPTY_NATIVE_SESSION: NativeSession = {
  active: false,
  id: null,
  startedAt: 0,
  plannedMs: 0,
  pausedAt: null,
  pausedTotalMs: 0,
  endedReason: null,
  endedAt: null,
  pendingCommand: null,
  pendingAt: null,
  blockedAttempts: 0,
};

/* ------------------------------------------------------------------ */
/* Building a session                                                  */
/* ------------------------------------------------------------------ */

export function timerToNative(t: ActiveTimer): NativeTimer {
  return {
    id: t.id,
    startedAt: t.startedAt,
    plannedMs: t.plannedMs,
    pausedAt: t.pausedAt,
    pausedTotalMs: t.pausedTotalMs,
  };
}

export function guardOptions(g: GuardConfig): GuardOptions {
  return { blockedPackages: g.blockedApps, floatingTimer: g.floatingTimer, dndMode: g.dndMode };
}

/** The guard settings for a new focus block, or null when the guard is off or has nothing to do. */
export function guardFromSettings(s: Pick<Settings, 'guardEnabled' | 'blockedApps' | 'floatingTimer' | 'dndMode'>): GuardConfig | null {
  if (!s.guardEnabled) return null;
  const blockedApps = [...new Set(s.blockedApps)];
  if (blockedApps.length === 0 && !s.floatingTimer && s.dndMode === 'off') return null;
  return { blockedApps, floatingTimer: s.floatingTimer, dndMode: s.dndMode };
}

/* ------------------------------------------------------------------ */
/* What is missing before the guard can do its job                     */
/* ------------------------------------------------------------------ */

export type PermissionKey = 'overlay' | 'detection' | 'notificationPolicy';

export interface MissingPermission {
  key: PermissionKey;
  title: string;
  why: string;
}

export function missingForGuard(g: GuardConfig, p: GuardPermissions): MissingPermission[] {
  const out: MissingPermission[] = [];
  const needsOverlay = g.floatingTimer || g.blockedApps.length > 0;
  if (needsOverlay && !p.overlay) {
    out.push({
      key: 'overlay',
      title: 'Display over other apps',
      why: g.blockedApps.length > 0
        ? 'Shows the floating timer and the screen that replaces a blocked app.'
        : 'Shows the floating timer on top of your study app.',
    });
  }
  if (g.blockedApps.length > 0 && !p.usageAccess && !p.accessibility) {
    out.push({
      key: 'detection',
      title: 'Usage access or Accessibility',
      why: 'Lets Majesto notice when one of the apps you chose comes to the front. Either one is enough.',
    });
  }
  if (g.dndMode !== 'off' && !p.notificationPolicy) {
    out.push({
      key: 'notificationPolicy',
      title: 'Do Not Disturb access',
      why: 'Lets Majesto turn on Do Not Disturb for the session and put it back afterwards.',
    });
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Keeping the app and the native service in step                      */
/* ------------------------------------------------------------------ */

export type GuardAction =
  | { type: 'none' }
  /** Hand the running session to the native service. Safe to repeat: the service ignores a second start. */
  | { type: 'start' }
  /** The app changed the timer (pause or resume): copy it to the native side. */
  | { type: 'sync' }
  /** No guarded session is running any more: clear the native side. */
  | { type: 'stop-native' }
  /** The person pressed something on the floating timer: apply it to the app, then acknowledge. */
  | { type: 'apply'; command: NativeCommand; at: number };

const TOLERANCE_MS = 50;

function sameTimer(t: ActiveTimer, n: NativeSession): boolean {
  return (
    n.startedAt === t.startedAt &&
    n.plannedMs === t.plannedMs &&
    (n.pausedAt === null) === (t.pausedAt === null) &&
    Math.abs(n.pausedTotalMs - t.pausedTotalMs) <= TOLERANCE_MS
  );
}

/**
 * Decide what the app should do so that the timer in the store and the native service agree.
 *
 * The store is the single source of truth. The native side only ever changes the timer when the person
 * presses a control on the floating timer, and then it leaves a `pendingCommand` for the app to apply.
 * Nothing here pauses, stops or restarts a session because Majesto was opened or closed, so opening the AI
 * assistant can never switch the restrictions off.
 */
export function reconcileGuard(timer: ActiveTimer | null, native: NativeSession, now: number): GuardAction {
  const guarded = !!timer && timer.kind === 'focus' && !!timer.guard;

  if (!timer || !guarded) {
    // Nothing guarded is running. Clear leftovers, but don't touch a clean native side.
    return native.active || native.endedReason || native.pendingCommand ? { type: 'stop-native' } : { type: 'none' };
  }

  const sameSession = native.id === timer.id;

  if (sameSession && native.pendingCommand && native.pendingAt !== null) {
    return { type: 'apply', command: native.pendingCommand, at: native.pendingAt };
  }

  if (!sameSession) {
    // Either a fresh session, or the app was restarted and the native side lost it (reboot, force stop).
    return isExpired(timer, now) ? { type: 'none' } : { type: 'start' };
  }

  if (native.endedReason === 'expired') return { type: 'none' }; // the app finishes expired timers itself
  if (!native.active) return isExpired(timer, now) ? { type: 'none' } : { type: 'start' };

  return sameTimer(timer, native) ? { type: 'none' } : { type: 'sync' };
}

/** HH:MM:SS, as shown on the floating timer. */
export function formatHms(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}
