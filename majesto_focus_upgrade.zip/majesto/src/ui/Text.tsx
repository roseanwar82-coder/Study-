import { Text, type TextProps } from 'react-native';
import { colors, typeStyles, type ColorName, type TypeVariant } from './theme';

interface Props extends TextProps {
  variant?: TypeVariant;
  color?: ColorName;
}

export function Txt({ variant = 'body', color = 'text', style, ...rest }: Props) {
  return <Text {...rest} style={[typeStyles[variant], { color: colors[color] }, style]} />;
}
