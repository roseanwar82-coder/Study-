import { useEffect, useState } from 'react';
import { focusGuard } from '@/services/focusGuard';
import type { GuardPermissions } from '@/core/guard';
import { AppState } from 'react-native';

/** How many times a blocked app was stopped during the running session. */
export function useBlockedAttempts(active: boolean): number {
  const [n, setN] = useState(() => (active ? focusGuard.getSessionState().blockedAttempts : 0));
  useEffect(() => {
    if (!active) {
      setN(0);
      return;
    }
    setN(focusGuard.getSessionState().blockedAttempts);
    return focusGuard.on('onBlocked', (e) => setN(e.attempts));
  }, [active]);
  return n;
}

/** Android permission state, re-read whenever the app returns from Settings. */
export function useGuardPermissions(): { permissions: GuardPermissions; refresh: () => void } {
  const [permissions, setPermissions] = useState<GuardPermissions>(() => focusGuard.getPermissions());
  useEffect(() => {
    const refresh = () => setPermissions(focusGuard.getPermissions());
    refresh();
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') refresh();
    });
    return () => sub.remove();
  }, []);
  return { permissions, refresh: () => setPermissions(focusGuard.getPermissions()) };
}
