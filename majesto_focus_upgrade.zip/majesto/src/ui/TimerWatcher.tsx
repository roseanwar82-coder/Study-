import { useEffect } from 'react';
import { elapsedMs } from '@/core/focus';
import { formatMinutes } from '@/core/time';
import { cancelTimerEnd } from '@/services/notifications';
import { actions, useApp } from '@/store';
import { useNow } from './hooks';

/** How long the Focus screen gets to finish an expired timer itself, so it can show its result card. */
const GRACE_MS = 3000;

/**
 * Safety net for timers that run out while the Focus tab isn't on screen (or the app was closed).
 * Without it the block would only be logged the next time Focus is opened, and Today's rings
 * and the streak would lag behind.
 */
export function TimerWatcher() {
  const timer = useApp((s) => s.timer);
  const running = !!timer && timer.pausedAt === null;
  const now = useNow(running, 1000);

  const overdue = timer && running ? elapsedMs(timer, now) - timer.plannedMs >= GRACE_MS : false;

  useEffect(() => {
    if (!overdue) return;
    cancelTimerEnd();
    const res = actions.finishTimer(true);
    if (!res) return;
    if (res.kind === 'focus' && res.session) {
      actions.pushToast('Focus block complete', `${formatMinutes(res.session.actualMs)} logged. +${res.xp} XP`);
    } else if (res.kind === 'break') {
      actions.pushToast('Break is over', 'Ready for the next block?');
    }
  }, [overdue]);

  return null;
}
