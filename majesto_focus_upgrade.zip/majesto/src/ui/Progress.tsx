import { StyleSheet, View } from 'react-native';
import type { ReactNode } from 'react';
import Svg, { Circle, G } from 'react-native-svg';
import { Txt } from './Text';
import { colors, radius } from './theme';
import type { WeekDay } from '@/core/stats';

export function ProgressBar({ ratio, color = colors.gold, height = 6 }: { ratio: number; color?: string; height?: number }) {
  const pct = Math.round(Math.min(1, Math.max(0, ratio)) * 100);
  return (
    <View
      accessibilityRole="progressbar"
      accessibilityValue={{ min: 0, max: 100, now: pct }}
      style={[styles.track, { height, borderRadius: height }]}
    >
      <View style={{ width: `${pct}%`, height, borderRadius: height, backgroundColor: color }} />
    </View>
  );
}

interface Ring {
  ratio: number;
  color: string;
}

/** One or more concentric rings, outermost first. */
export function Rings({ size, stroke, rings, children }: { size: number; stroke: number; rings: Ring[]; children?: ReactNode }) {
  const gap = 4;
  const c = size / 2;
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size}>
        {rings.map((ring, i) => {
          const r = c - stroke / 2 - i * (stroke + gap);
          const circ = 2 * Math.PI * r;
          const ratio = Math.min(1, Math.max(0, ring.ratio));
          return (
            <G key={i}>
              <Circle cx={c} cy={c} r={r} stroke={ring.color} strokeOpacity={0.16} strokeWidth={stroke} fill="none" />
              {ratio > 0 ? (
                <Circle
                  cx={c}
                  cy={c}
                  r={r}
                  stroke={ring.color}
                  strokeWidth={stroke}
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={`${circ} ${circ}`}
                  strokeDashoffset={circ * (1 - ratio)}
                  rotation={-90}
                  origin={`${c}, ${c}`}
                />
              ) : null}
            </G>
          );
        })}
      </Svg>
      {children ? <View style={StyleSheet.absoluteFill}><View style={styles.center}>{children}</View></View> : null}
    </View>
  );
}

export function WeekBars({ days, tint = colors.gold }: { days: WeekDay[]; tint?: string }) {
  const H = 72;
  return (
    <View style={styles.weekRow}>
      {days.map((d) => (
        <View key={d.key} style={styles.weekCol}>
          <View style={{ height: H, justifyContent: 'flex-end' }}>
            <View
              style={{
                width: 22,
                height: Math.max(d.xp > 0 ? 8 : 4, Math.round(H * d.ratio)),
                borderRadius: radius.sm / 2,
                backgroundColor: d.active ? tint : d.xp > 0 ? tint + '66' : colors.border,
              }}
            />
          </View>
          <Txt variant="caption" style={{ color: d.isToday ? colors.text : colors.textFaint, fontWeight: d.isToday ? '700' : '400' }}>
            {d.letter}
          </Txt>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  track: { backgroundColor: colors.surfaceHi, overflow: 'hidden' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  weekRow: { flexDirection: 'row', justifyContent: 'space-between' },
  weekCol: { alignItems: 'center', gap: 6 },
});
