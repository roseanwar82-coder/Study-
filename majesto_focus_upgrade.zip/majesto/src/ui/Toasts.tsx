import { useEffect, useRef } from 'react';
import { Animated, Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { actions, useApp } from '@/store';
import { haptic } from '@/services/haptics';
import { Txt } from './Text';
import { colors, radius, space } from './theme';

const VISIBLE_MS = 3600;

/** Shows the oldest queued toast (level-ups, unlocked achievements), one at a time. */
export function ToastHost() {
  const toast = useApp((s) => s.toasts[0] ?? null);
  const insets = useSafeAreaInsets();
  const slide = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!toast) return;
    haptic.success();
    slide.setValue(0);
    Animated.spring(slide, { toValue: 1, useNativeDriver: true, friction: 8 }).start();
    const timer = setTimeout(() => actions.dismissToast(toast.id), VISIBLE_MS);
    return () => clearTimeout(timer);
  }, [toast?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!toast) return null;
  const isLevel = toast.kind === 'level';
  const tint = isLevel ? colors.gold : colors.sage;

  return (
    <View pointerEvents="box-none" style={[styles.host, { top: insets.top + space.sm }]}>
      <Animated.View
        style={{
          opacity: slide,
          transform: [{ translateY: slide.interpolate({ inputRange: [0, 1], outputRange: [-24, 0] }) }],
        }}
      >
        <Pressable
          accessibilityRole="alert"
          onPress={() => actions.dismissToast(toast.id)}
          style={[styles.toast, { borderColor: tint + '88' }]}
        >
          <Ionicons name={isLevel ? 'arrow-up-circle' : 'ribbon'} size={26} color={tint} />
          <View style={{ flex: 1 }}>
            <Txt variant="heading">{toast.title}</Txt>
            <Txt variant="small" color="textDim">{toast.body}</Txt>
          </View>
        </Pressable>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  host: { position: 'absolute', left: 0, right: 0, paddingHorizontal: space.lg, zIndex: 100 },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    backgroundColor: colors.surfaceHi,
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: space.lg,
  },
});
