import { useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { createRng } from '@/core/rng';
import { NBACK_TRIALS, generateNBack, scoreNBack, type NBackTrial } from '@/core/drills/nback';
import { haptic } from '@/services/haptics';
import { Button } from '@/ui/Button';
import { ProgressBar } from '@/ui/Progress';
import { Txt } from '@/ui/Text';
import { areaColor, colors, fonts, radius, space } from '@/ui/theme';
import type { DrillProps } from './types';

const LEAD_MS = 1200;
const SHOW_MS = 1500;
const TRIAL_MS = 2200;

export function NBackDrill({ level: n, onFinish }: DrillProps) {
  const seq = useMemo(() => generateNBack(createRng(), n), [n]);
  const startedAt = useRef(Date.now());
  const results = useRef<NBackTrial[]>([]);
  const responded = useRef(false);

  const [index, setIndex] = useState(-1); // -1 while getting ready
  const [visible, setVisible] = useState(false);
  const [pressed, setPressed] = useState(false);

  useEffect(() => {
    if (index === -1) {
      const t = setTimeout(() => setIndex(0), LEAD_MS);
      return () => clearTimeout(t);
    }
    responded.current = false;
    setPressed(false);
    setVisible(true);
    const hide = setTimeout(() => setVisible(false), SHOW_MS);
    const advance = setTimeout(() => {
      results.current.push({ target: seq.targets[index], responded: responded.current });
      if (index + 1 >= NBACK_TRIALS) {
        const s = scoreNBack(n, results.current);
        onFinish({ points: s.points, summary: s.summary, accuracy: s.balanced, durationMs: Date.now() - startedAt.current, nextLevel: s.nextLevel });
      } else {
        setIndex(index + 1);
      }
    }, TRIAL_MS);
    return () => {
      clearTimeout(hide);
      clearTimeout(advance);
    };
  }, [index]); // eslint-disable-line react-hooks/exhaustive-deps

  const match = () => {
    if (index < 0 || responded.current) return;
    responded.current = true;
    setPressed(true);
    haptic.press();
  };

  return (
    <View style={styles.wrap}>
      <View style={{ gap: space.sm }}>
        <Txt variant="small" color="textDim">{n}-back. Tap Match when the letter equals the one from {n} step{n === 1 ? '' : 's'} ago.</Txt>
        <ProgressBar ratio={Math.max(0, index) / NBACK_TRIALS} color={areaColor.drills} />
      </View>

      <View style={styles.stage}>
        {index === -1 ? (
          <Txt variant="heading" color="textDim">Get ready</Txt>
        ) : (
          <Txt style={styles.letter}>{visible ? seq.stimuli[index] : ''}</Txt>
        )}
      </View>

      <Button
        title={pressed ? 'Marked' : 'Match'}
        variant={pressed ? 'secondary' : 'primary'}
        tint={areaColor.drills}
        size="lg"
        disabled={index < 0}
        onPress={match}
        style={{ minHeight: 72 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, gap: space.xl },
  stage: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  letter: { fontFamily: fonts.serif, fontSize: 120, lineHeight: 130, color: colors.text },
});
