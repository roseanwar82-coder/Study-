export interface DrillFinish {
  points: number;
  summary: string;
  accuracy: number | null;
  durationMs: number;
  /** Level to remember for next time. Defaults to the level just played. */
  nextLevel?: number;
}

export interface DrillProps {
  level: number;
  onFinish: (result: DrillFinish) => void;
}
