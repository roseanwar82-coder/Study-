import { useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { createRng } from '@/core/rng';
import { STROOP_COLORS, STROOP_TRIALS, generateStroopTrials, scoreStroop, type StroopAnswer, type StroopColorId } from '@/core/drills/stroop';
import { haptic } from '@/services/haptics';
import { ProgressBar } from '@/ui/Progress';
import { Txt } from '@/ui/Text';
import { areaColor, colors, fonts, radius, space } from '@/ui/theme';
import type { DrillProps } from './types';

const hexOf = (id: StroopColorId) => STROOP_COLORS.find((c) => c.id === id)!.hex;
const nameOf = (id: StroopColorId) => STROOP_COLORS.find((c) => c.id === id)!.name;

export function StroopDrill({ onFinish }: DrillProps) {
  const trials = useMemo(() => generateStroopTrials(createRng()), []);
  const startedAt = useRef(Date.now());
  const trialStart = useRef(Date.now());
  const answers = useRef<StroopAnswer[]>([]);
  const [index, setIndex] = useState(0);
  const [flash, setFlash] = useState<'ok' | 'bad' | null>(null);

  const trial = trials[index];

  const press = (id: StroopColorId) => {
    const correct = id === trial.ink;
    answers.current.push({ correct, rtMs: Date.now() - trialStart.current });
    correct ? haptic.tap() : haptic.error();
    setFlash(correct ? 'ok' : 'bad');
    setTimeout(() => setFlash(null), 160);

    if (index + 1 >= STROOP_TRIALS) {
      const s = scoreStroop(answers.current);
      onFinish({ points: s.points, summary: s.summary, accuracy: s.accuracy, durationMs: Date.now() - startedAt.current, nextLevel: 1 });
      return;
    }
    trialStart.current = Date.now();
    setIndex(index + 1);
  };

  return (
    <View style={styles.wrap}>
      <View style={{ gap: space.sm }}>
        <Txt variant="small" color="textDim">{index + 1} of {STROOP_TRIALS}</Txt>
        <ProgressBar ratio={index / STROOP_TRIALS} color={areaColor.drills} />
      </View>

      <View style={[styles.stage, flash === 'ok' && { borderColor: colors.success }, flash === 'bad' && { borderColor: colors.danger }]}>
        <Txt style={[styles.word, { color: hexOf(trial.ink) }]} accessibilityLabel={`The word ${nameOf(trial.word)} in some ink color`}>
          {nameOf(trial.word).toUpperCase()}
        </Txt>
        <Txt variant="small" color="textDim">Tap the color of the ink</Txt>
      </View>

      <View style={styles.buttons}>
        {STROOP_COLORS.map((c) => (
          <Pressable
            key={c.id}
            accessibilityRole="button"
            accessibilityLabel={c.name}
            onPress={() => press(c.id)}
            style={({ pressed }) => [styles.button, pressed && { backgroundColor: colors.surfaceHi }]}
          >
            <Txt variant="heading">{c.name}</Txt>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, gap: space.xl },
  stage: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: space.lg,
    borderRadius: radius.lg,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  word: { fontFamily: fonts.serif, fontSize: 60, lineHeight: 68, fontWeight: '700', letterSpacing: 2 },
  buttons: { flexDirection: 'row', flexWrap: 'wrap', gap: space.md },
  button: {
    width: '47.5%',
    height: 64,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
